﻿using System;
using System.Collections.Generic;

namespace AlphaBot.DataManagement.UserAccountsFolder
{
    public class UserAccount
    {
        // account (essential)
        public string Username { get; set; }
        public ulong ID { get; set; }
        public byte DialogueProgress { get; set; }

        // settings
        public string Language { get; set; }
        public bool AutoPrefix { get; set; } 
            public string AutoPrefix_AddedString { get; set; }
            public bool AutoPrefix_Notifications { get; set; }
            public byte AutoPrefix_UnknownCommandsCounter { get; set; }
        public bool PreferDM { get; set; }

        // statistics
        public int CommandsUsed { get; set; }
        public DateTime DateOfJoin { get; set; }

        // acount info
        public DateTime DateOfBirth { get; set; }






        public int Restriction { get; set; }


        /* Progress */
        public int Points { get; set; }
        public double Currency { get; set; }
        public uint Level
        {
            get
            {
                return (uint)Math.Sqrt(XP / 50);
            }
            set
            { }
        }
        public uint XP { get; set; }
        public byte TLastMessage { get; set; }
        public byte TLastDaily { get; set; }
        public int NDailySeries { get; set; }
        public int NDailyPermanentSeries { get; set; }
        public int NDailyHighestSeries { get; set; }


        /* Profile */
        public string Sex { get; set; } // M / W
        public string DoB { get; set; } // DD.MM.JJJJ
        public string DoJ { get; set; } // DD.MM.JJJJ
        public string PP { get; set; }  // Url      
        // Colors          
        public int Hex1 { get; set; }
        public int Hex2 { get; set; }
        public int Hex3 { get; set; }
        // Badges        
        public int Alpha { get; set; }              // 0 = No Alpha Member | 1 = Alpha Rekrut | 2 = Alpha Mitglied | 3 = Alpha Anführer
        public int MembershipPluses { get; set; }   // 0 = None | 1 = Home Guard | 
        public int TimeEvent { get; set; }          // 1??? = Halloween | ?1?? = Summer | ??1? = Eastern | ???1 = New Year 


        /* Channelchosing */
        // public int RTrash { get; set; }


        /* Inventory */
        public int CacheStatus { get; set; } // 0 = nichts | 1 = Anfragen müssen gecachet werden | 2 = Anfrager muss Storen | 3 = beides
        public int TradingStatus { get; set; }
        public int NotificationStatus { get; set; }
        // Storeing
        public int StoreCurrency { get; set; }
        public int StoreID { get; set; }
        // Anfragende
        public ulong RequestingPartnerID { get; set; }
        public ulong CacheRequestingPartnerID { get; set; }
        // Anfrage                        
        public ulong WantedPartnerID { get; set; }
        public int WantedObjectID { get; set; }
        public int OwnObjectID { get; set; }
        // Acception
        public double CurrencyMinus { get; set; }
        public int ItemMinus { get; set; }

        public List<Part> parts = new List<Part>();
        public class Part : IEquatable<Part>
        {
            public int PartId { get; set; }

            public override string ToString()
            {
                return PartId.ToString();
            }
            public override bool Equals(object obj)
            {
                if (obj == null) return false;
                Part objAsPart = obj as Part;
                if (objAsPart == null) return false;
                else return Equals(objAsPart);
            }
            public override int GetHashCode()
            {
                return PartId;
            }
            public bool Equals(Part other)
            {
                if (other == null) return false;
                return (this.PartId.Equals(other.PartId));
            }
        }
    }
}
