﻿using System.Linq;
using System.Collections.Generic;
using Discord.WebSocket;

using AlphaBot.DataManagement.ServerAccountsFolder;

namespace AlphaBot.DataManagement.ServerAccountsFolder
{
    public static class ServerAccounts
    {
        private static List<ServerAccount> serverAccounts;
        private static string serverAccountsFile = "Resources/serverAccounts.json";

        static ServerAccounts()
        {
            if (DataStorageServer.SaveExists(serverAccountsFile))
            {
                if (DataStorageServer.ServerAccountFileAvailable == 0) //
                { //
                    ZSystem.ErrorHandler.CatchError("ERROR1"); //
                    return; //
                } //


                serverAccounts = DataStorageServer.LoadServerAccounts(serverAccountsFile).ToList();
            }
            else
            {
                serverAccounts = new List<ServerAccount>();
                SaveAccounts();
            }
        }

        public static void SaveAccounts()
        {
            DataStorageServer.SaveServerAccounts(serverAccounts, serverAccountsFile);
        }
        internal static void SaveAccounts(string fileName)
        {
            DataStorageServer.SaveServerAccounts(serverAccounts, fileName);
        }

        public static ServerAccount GetServerAccount(SocketGuild guild)
        {
            return GetOrCreateServerAccount(guild.Id);
        }

        public static ServerAccount GetOrCreateServerAccount(ulong id)
        {
            var result = from s in serverAccounts
                       where s.ID == id
                       select s;
            var serverAccount = result.FirstOrDefault();
            if (serverAccount == null) serverAccount = CreateServerAccount(id);
            return serverAccount;
        }

        private static ServerAccount CreateServerAccount(ulong id)
        {
            var newServerAccount = new ServerAccount()
            {
                Servername = "",
                ID = id,
                ServerLanguage = Config.bot.guild_default_language,
                Prefix = Config.bot.guild_default_prefix,
                ServerAdmins = "x",
                BotChannels = "x",
                DialogueProgress = 0,
            };

            serverAccounts.Add(newServerAccount);
            ServerAccounts.SaveAccounts();
            return newServerAccount;
        }
    }
}
