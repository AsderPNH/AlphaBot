﻿using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json;

using AlphaBot.DataManagement.ServerAccountsFolder;

namespace AlphaBot.DataManagement.ServerAccountsFolder
{
    public static class DataStorageServer
    {
        internal static byte ServerAccountFileAvailable { get; set; } // 0=unavailable 1=available 2=internalAvailable

        // Save all serverAccounts
        public static void SaveServerAccounts(IEnumerable<ServerAccount> serverAccounts, string filePath)
        {
            if (ServerAccountFileAvailable == 0 || ServerAccountFileAvailable == 2) //
            { //
                ZSystem.ErrorHandler.CatchError("ERROR1"); //
                return; //
            } //


            string json = JsonConvert.SerializeObject(serverAccounts, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(filePath, json);
            return;
        }

        // Get all serverAccounts
        public static IEnumerable<ServerAccount> LoadServerAccounts(string filePath)
        {            
            if (!File.Exists(filePath)) return null;
            string json = File.ReadAllText(filePath);            
            return JsonConvert.DeserializeObject<List<ServerAccount>>(json);
        }

        public static bool SaveExists(string filePath)
        {
            return File.Exists(filePath);
        }
    }
}
