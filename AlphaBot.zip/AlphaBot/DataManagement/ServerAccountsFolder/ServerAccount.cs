﻿using System;

namespace AlphaBot.DataManagement.ServerAccountsFolder
{
    public class ServerAccount
    {
        public string Servername { get; set; }
        public ulong ID { get; set; }
        public string ServerLanguage { get; set; }
        public string Prefix { get; set; }
        public string ServerAdmins { get; set; }
        public string BotChannels { get; set; }
        public byte DialogueProgress { get; set; }
    }
}
