﻿using AlphaBot.DataManagement.UserAccountsFolder;
using AlphaBot.Formatting;
using Discord.Commands;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AlphaBot.Modules.MiscSupply.ProfileSupply
{
    class AutoPrefix
    {
        internal static Task SetAutoPrefix(string commandText, SocketCommandContext context)
        {
            var userAccount = UserAccounts.GetUserAccount(context.User.Id);

            if (commandText == "") // negating auto prefix if no further instructions are given
            {
                userAccount.AutoPrefix = !userAccount.AutoPrefix;
            }
            
            string[] strings = commandText.Split(" "); // splits commandText into string array

            string newAutoPrefix = ""; // initializing string to add to autoPrefix

            foreach (string s in strings)
            {
                // if space is wanted
                if (ZTools.GeneralTools.StringIsAnyOfStringArray(s, Utilities.GetAlert("OTHER_p-setAutoPrefix-emptySpace_ANYOF"), "|")) 
                {
                    newAutoPrefix += " ";
                }
                // if autoPrefix should be turned on
                else if (ZTools.GeneralTools.StringIsAnyOfStringArray(targetString: strings[0], stringArray: Utilities.GetAlert("OTHER_p-setAutoPrefix-on_ANYOF"), stringSeperator: "|"))
                {
                    userAccount.AutoPrefix = true;
                }
                // if autoPrefix should be turned off
                else if (ZTools.GeneralTools.StringIsAnyOfStringArray(targetString: strings[0], stringArray: Utilities.GetAlert("OTHER_p-setAutoPrefix-off_ANYOF"), stringSeperator: "|"))
                {
                    userAccount.AutoPrefix = false;
                }
                // if autoPrefix notifications should be turned off
                else if (ZTools.GeneralTools.StringIsAnyOfStringArray(targetString: strings[0], stringArray: Utilities.GetAlert("OTHER_p-setAutoPrefix-mute_ANYOF"), stringSeperator: "|"))
                {
                    userAccount.AutoPrefix_Notifications = false;
                }
                // if autoPrefix notifications should be turned on
                else if (ZTools.GeneralTools.StringIsAnyOfStringArray(targetString: strings[0], stringArray: Utilities.GetAlert("OTHER_p-setAutoPrefix-unmute_ANYOF"), stringSeperator: "|"))
                {
                    userAccount.AutoPrefix_Notifications = true;
                }
                // if string should be added
                else
                {
                    newAutoPrefix += $"{s} ";
                }
            }

            userAccount.AutoPrefix_AddedString = newAutoPrefix;
            return Task.CompletedTask;
        }
    }
}
