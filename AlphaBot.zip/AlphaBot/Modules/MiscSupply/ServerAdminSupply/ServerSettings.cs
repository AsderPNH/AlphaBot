﻿using System;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;

using AlphaBot.DataManagement.ServerAccountsFolder;
using System.Runtime.CompilerServices;

namespace AlphaBot.Modules.MiscSupply.ServerAdminSupply
{
    class ServerSettings
    {
        internal static Task SetPrefix(string prefix, SocketCommandContext context)
        {
            if (Core.LocalPermissionFolder.LocalPermission.HasLocalPermission((SocketGuildUser)context.User))
            {
                ServerAccount serverAccount = ServerAccounts.GetServerAccount(context.Guild);
                serverAccount.Prefix = prefix;
                context.Channel.SendMessageAsync($"{Formatting.Utilities.GetAlert("EMOTE_true")} | {Formatting.LanguagePacks.GetFormattedSentence(context.User, context.Guild, "a-SetPrefix-Success_&PREFIX", prefix)}");
            }
            else
            {
                context.Channel.SendMessageAsync($"{Formatting.Utilities.GetAlert("EMOTE_false")} | {Formatting.LanguagePacks.GetSentence(context.User, context.Guild, "ERROR_Permission")}");
            }
            return Task.CompletedTask;
        }

        internal static Task SetBotchannel(string unknownString, SocketCommandContext context)
        {
            if (Core.LocalPermissionFolder.LocalPermission.HasLocalPermission((SocketGuildUser)context.User)) // if user has admin rights
            {
                ServerAccount serverAccount = ServerAccounts.GetServerAccount(context.Guild);

                for (int i = 0; i < unknownString.Length; i++) // removing empty spaces
                {
                    if (unknownString[i] == ' ') unknownString = unknownString.Remove(i, 1);
                }

                string[] unknownStrings = unknownString.Split('|'); // splitting string 

                string channelsToAdd = "";

                foreach (string s in unknownStrings)
                {
                    if (s == "every" || s == "any" || s == "each") // checking if every channel is wanted
                    {
                        serverAccount.BotChannels = "any";
                        ServerAccounts.SaveAccounts(); // save recent changes
                        return Task.CompletedTask;
                    }
                    else if (s == "this" || s == "here") // checking if current channel is "mentioned"
                    {
                        if (serverAccount.BotChannels.Contains(context.Channel.Id.ToString()) == false) // checking if current channel is already on list
                        {
                            channelsToAdd += $"{context.Channel.Id}|";
                        }
                    }
                    else if (MentionUtils.TryParseChannel(s, out ulong channelId) == true) // checking if channel is mentioned
                    {
                        if (serverAccount.BotChannels.Contains(channelId.ToString()) == false) // checking if current channel is already on list
                        {
                            channelsToAdd += $"{channelId}|";
                        }
                    }

                    if (serverAccount.BotChannels == "x") // if BotChannels have not been set
                    {
                        serverAccount.BotChannels = channelsToAdd; // replace 'x' with channels
                    }
                    else
                    {
                        serverAccount.BotChannels += channelsToAdd; // add channels to string
                    }
                }
                ServerAccounts.SaveAccounts(); // save recent changes
            }
            else // if user has no admin rights
            {
                context.Channel.SendMessageAsync($"{Formatting.Utilities.GetAlert("EMOTE_false")} | {Formatting.LanguagePacks.GetSentence(context.User, context.Guild, "ERROR_Permission")}");
            }
            return Task.CompletedTask;
        }

        internal static Task ClearBotchannels(SocketCommandContext context)
        {
            if (Core.LocalPermissionFolder.LocalPermission.HasLocalPermission((SocketGuildUser)context.User)) // if user has admin rights
            {
                ServerAccount serverAccount = ServerAccounts.GetServerAccount(context.Guild);

                serverAccount.BotChannels = "x";
            }
            else // if user has no admin rights
            {
                context.Channel.SendMessageAsync($"{Formatting.Utilities.GetAlert("EMOTE_false")} | {Formatting.LanguagePacks.GetSentence(context.User, context.Guild, "ERROR_Permission")}");
            }
            return Task.CompletedTask;
        }

        internal static Task SetLocalAdmin(string unknownString, SocketCommandContext context)
        {
            if (Core.LocalPermissionFolder.LocalPermission.HasLocalPermission((SocketGuildUser)context.User)) // if user has admin rights
            {
                ServerAccount serverAccount = ServerAccounts.GetServerAccount(context.Guild);

                for (int i = 0; i < unknownString.Length; i++) // removing empty spaces
                {
                    if (unknownString[i] == ' ') unknownString = unknownString.Remove(i, 1);
                }

                string[] unknownStrings = unknownString.Split('|'); // splitting string 

                string usersToAdd = "";

                foreach (string s in unknownStrings)
                {
                    if (MentionUtils.TryParseUser(s, out ulong userId) == true) // checking if user is mentioned
                    {
                        if (serverAccount.ServerAdmins.Contains(userId.ToString()) == false) // checking if current user is already on list
                        {
                            usersToAdd += $"{userId}|";
                        }
                    }

                    if (serverAccount.ServerAdmins == "x") // if ServerAdmins have not been set
                    {
                        serverAccount.ServerAdmins = usersToAdd; // replace 'x' with users
                    }
                    else
                    {
                        serverAccount.ServerAdmins += usersToAdd; // add users to string
                    }
                }
                ServerAccounts.SaveAccounts(); // save recent changes
            }
            else // if user has no admin rights
            {
                context.Channel.SendMessageAsync($"{Formatting.Utilities.GetAlert("EMOTE_false")} | {Formatting.LanguagePacks.GetSentence(context.User, context.Guild, "ERROR_Permission")}");
            }
            return Task.CompletedTask;
        }

        internal static Task ClearAdmins(SocketCommandContext context)
        {
            if (Core.LocalPermissionFolder.LocalPermission.HasLocalPermission((SocketGuildUser)context.User)) // if user has admin rights
            {
                ServerAccount serverAccount = ServerAccounts.GetServerAccount(context.Guild);

                serverAccount.ServerAdmins = "x";
            }
            else // if user has no admin rights
            {
                context.Channel.SendMessageAsync($"{Formatting.Utilities.GetAlert("EMOTE_false")} | {Formatting.LanguagePacks.GetSentence(context.User, context.Guild, "ERROR_Permission")}");
            }
            return Task.CompletedTask;
        }

        internal static bool IsBotchannel(SocketCommandContext context)
        {
            ServerAccount serverAccount = ServerAccounts.GetServerAccount(context.Guild);
            if (serverAccount.BotChannels.Contains(context.Channel.Id.ToString()) == true || serverAccount.BotChannels == "any")
            {
                return true;
            }
            return false;
        }
    }
}
