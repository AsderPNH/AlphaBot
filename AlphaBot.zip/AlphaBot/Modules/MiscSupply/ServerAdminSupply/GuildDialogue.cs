﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

using Discord.Commands;
using Discord.WebSocket;

using AlphaBot.DataManagement.UserAccountsFolder;
using AlphaBot.DataManagement.ServerAccountsFolder;
using AlphaBot.Formatting;


namespace AlphaBot.Modules.MiscSupply.ServerAdminSupply
{
    class GuildDialogue
    {
        internal static Task SkipDialogue(SocketGuild guild)
        {
            ServerAccount serverAccount = ServerAccounts.GetServerAccount(guild);

            serverAccount.DialogueProgress = 255;

            return Task.CompletedTask;
        }

        internal static Task Dialogue(SocketCommandContext context)
        {
            ServerAccount serverAccount = ServerAccounts.GetServerAccount(context.Guild);
            Discord.EmbedBuilder embed = new Discord.EmbedBuilder(); // new embed

            embed.WithThumbnailUrl("https://raw.githubusercontent.com/AsderPNH/AlphaBot/Icons/Icon_Gear.png");
            embed.WithColor(new Discord.Color(255, 255, 0));

            if (serverAccount.DialogueProgress == 0 && serverAccount.Prefix == Config.bot.guild_default_prefix)
            {
                embed.Description = LanguagePacks.GetFormattedSentence // embed-description
                    (context.User, context.Guild,
                    "a-dialogue-1_&COMMAND", // description
                    $"`{serverAccount.Prefix}{Utilities.GetAlert("COMMAND_guildAdmin-skipServerDialogue")}`"); // argument1 with current prefix

                embed.AddField($"`{serverAccount.Prefix}{Utilities.GetAlert("COMMAND_help-specificCommand")}`",
                    LanguagePacks.GetSentence(context.User, context.Guild, "a-dialogue-help-description"));

                embed.AddField($"`{serverAccount.Prefix}{Utilities.GetAlert("COMMAND_guildAdmin-setPrefix")}`",
                     LanguagePacks.GetFormattedSentence(context.User, context.Guild, "a-dialogue-setPrefix-description_&PREFIX", $"`{serverAccount.Prefix}`"));

                embed.AddField(LanguagePacks.GetSentence(context.User, context.Guild, "a-dialogue-hint"),
                     $"{LanguagePacks.GetFormattedSentence(context.User, context.Guild, "a-dialogue-hint-description_&COMMAND", $"`{serverAccount.Prefix}{Utilities.GetAlert("COMMAND_help-setPrefix")}`")}");

                context.Channel.SendMessageAsync(embed: embed.Build());

                serverAccount.DialogueProgress = 1;
                ServerAccounts.SaveAccounts();
                return Task.CompletedTask;
            }
            else if (serverAccount.DialogueProgress == 0)
            {
                serverAccount.DialogueProgress = 1;
            }

            if (serverAccount.DialogueProgress == 1)
            {

            }
            
            UserAccounts.SaveAccounts();
            return Task.CompletedTask;
        }
    }
}