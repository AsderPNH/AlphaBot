﻿using System.Threading.Tasks;

using Discord;
using Discord.Commands;
using Discord.WebSocket;

using AlphaBot.Formatting;
using AlphaBot.DataManagement.UserAccountsFolder;

namespace AlphaBot.Modules.MiscSupply.HelpSupply
{
    class Help
    {
        internal static Task GeneralHelp(SocketCommandContext context)
        {
            var userAccount = DataManagement.UserAccountsFolder.UserAccounts.GetUserAccount(context.User.Id);
            var serverAccount = DataManagement.ServerAccountsFolder.ServerAccounts.GetServerAccount(context.Guild);

            // server dialogue
            if (serverAccount.DialogueProgress == 0 && Core.LocalPermissionFolder.LocalPermission.HasLocalPermission(context.Guild.CurrentUser))
            {
                Modules.MiscSupply.ServerAdminSupply.GuildDialogue.Dialogue(context);
            }
            // user dialogue
            else if (userAccount.DialogueProgress == 1) 
            {
                Modules.MiscSupply.ProfileSupply.ProfileDialogue.Dialogue(context);
            }
            // general help
            else
            {
            
                var embed = new EmbedBuilder();
                embed.WithThumbnailUrl("https://raw.githubusercontent.com/AsderPNH/AlphaBot/Pictures/AP_Help.png");
                embed.WithColor(new Color(103, 58, 183));
                embed.WithTitle($"{Utilities.GetAlert("EMOTE_question-mark")} | {serverAccount.Prefix}{Utilities.GetAlert("COMMAND_help")}");
                embed.WithDescription(Formatting.LanguagePacks.GetFormattedSentence(context, "h-generalHelp-embed-description", $"{serverAccount.Prefix}{Utilities.GetAlert("COMMAND_help-specificCategory")}"));
                
                if (ZSystem.GlobalPermission.HasGlobalPermission(context.User))
                {
                    embed.AddField(Utilities.GetAlert("OTHER_h-generalHelp-category-botAdmin"), Formatting.LanguagePacks.GetSentence(context, ""));
                }

                context.Channel.SendMessageAsync(embed: embed.Build());
            }

            return Task.CompletedTask;
        }

        internal static Task CategoryHelp(string category, SocketCommandContext context)
        {
            /// category help
            return Task.CompletedTask;
        }

        internal static Task CommandHelp(string command, SocketCommandContext context)
        {
            if (ZTools.GeneralTools.StringIsAnyOfStringArray(command, Utilities.GetAlert("OTHER_h-categoryHelp-categories")))
            {
                CategoryHelp(command, context);
                return Task.CompletedTask;
            }

            var serverAccount = DataManagement.ServerAccountsFolder.ServerAccounts.GetServerAccount(context.Guild);

            EmbedBuilder embed = new EmbedBuilder();                    

            embed.WithColor(103, 58, 183); // help-color

            // Error 
            if (LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandDescription-{command}") == "") // if command explanation was not found
            {
                embed.WithTitle($"{Utilities.GetAlert("EMOTE_error")} | {LanguagePacks.GetSentence(context.User, context.Guild, "h-commandError")}"); // title with error
                embed.WithDescription(LanguagePacks.GetSentence(context.User, context.Guild, "h-commandError-description")); // error explanation

                context.Channel.SendMessageAsync(embed: embed.Build());
                return Task.CompletedTask; // return
            }
            // Success
            else
            {
                embed.WithTitle($"❓ | {serverAccount.Prefix}{command}"); // title with prefix
                embed.WithDescription(LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandDescription-{command}")); // command explanation

                // Syntax
                if (LanguagePacks.GetSentence("!help", $"h-commandSyntax-{command}").Contains("{1}")) // if syntax ist formattedSentence with 2 arguments
                {
                    embed.AddField(  // field
                        LanguagePacks.GetSentence( // field with syntax (name(title))
                                                  context.User, // priority language by SocketUser
                                                  context.Guild, // optional language by SocketGuild
                                                  $"h-commandSyntax"), // key of Syntax-Title (eng="Syntax")
                        LanguagePacks.GetFormattedSentence( // field with syntax (value(description))
                                                           "!help", // language=extra file
                                                           "", // "
                                                           $"h-commandSyntax-{command}", // key of Syntax-Description
                                                           LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandArgument1-{command}"), // argument1
                                                           LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandArgument2-{command}")));  // argument2
                }
                else if (LanguagePacks.GetSentence("!help", $"h-commandSyntax-{command}").Contains("{0}")) // if syntax ist formattedSentence with 1 argument
                {
                    embed.AddField(LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandSyntax"),
                    LanguagePacks.GetFormattedSentence("!help", "", $"h-commandSyntax-{command}", LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandArgument1-{command}")));
                }
                else
                {
                    embed.AddField(LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandSyntax"),
                    LanguagePacks.GetSentence("!help", $"h-commandSyntax-{command}"));
                }


                // Examples
                if (LanguagePacks.GetSentence("!help", $"h-commandExample-{command}") != "") // if command has example
                {
                    embed.AddField(LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandExample"), // field with example (name(title)
                        string.Format(LanguagePacks.GetSentence("!help", $"h-commandExample-{command}"), serverAccount.Prefix)); // " (value(description))
                }


                // Aliases
                if (LanguagePacks.GetSentence("!help", $"h-commandAliases-{command}") != "")
                {
                    if (LanguagePacks.GetSentence("!help", $"h-commandAliases-{command}").Contains("{1}"))
                    {
                        embed.AddField(LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandAliases"),
                        LanguagePacks.GetFormattedSentence("!help", "", $"h-commandAliases-{command}", 
                            LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandArgument1-{command}"), 
                            LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandArgument2-{command}")));                        
                    }
                    else if (LanguagePacks.GetSentence("!help", $"h-commandAliases-{command}").Contains("{0}")) // if syntax ist formattedSentence with 1 argument
                    {
                        embed.AddField(LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandAliases"),
                        LanguagePacks.GetFormattedSentence("!help", "", $"h-commandAliases-{command}", 
                            LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandArgument1-{command}")));
                    }
                    else                           
                    {
                        embed.AddField(LanguagePacks.GetSentence(context.User, context.Guild, $"h-commandAliases"), // field with aliases (name(title)
                            string.Format(LanguagePacks.GetSentence("!help", $"h-commandAliases-{command}"), serverAccount.Prefix)); // " (value(description))
                    }
                }

                context.Channel.SendMessageAsync(embed: embed.Build());
                return Task.CompletedTask;
            }
        }
    }
}
