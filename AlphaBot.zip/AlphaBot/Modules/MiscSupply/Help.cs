﻿using Discord;
using Discord.WebSocket;

using AlphaBot.Formatting;
using AlphaBot.DataManagement.UserAccountsFolder;

namespace AlphaBot.Modules.MiscSupply
{
    internal static class Help
    {
        internal static void DisplayHelp(ISocketMessageChannel Channel, SocketUser User)
        {
            DisplayGuildHelp("Help", Channel, User);
        }

        private static async void DisplayGuildHelp(string Command, ISocketMessageChannel Channel, SocketUser User)
        {
            int Rights = 0;
            var account = UserAccounts.GetOrCreateAccount(User.Id);
            if (Process.UserIsStaff((SocketGuildUser)User))
            {
                Rights = 1;
            }
            if (account.MembershipPluses > 1)
            {
                Rights = 2;
            }
            if (Process.UserIsBesitzer((SocketGuildUser)User))
            {
                Rights = 3;
            }
            
            /*var builder = new EmbedBuilder()
            {
                //Optional color
                Color = Color.Green,
                Description = "This is the description of the embed message"
                
            };*/

            var Intro = new EmbedBuilder();
            Intro.WithTitle("Übersicht");
            Intro.WithColor(103, 58, 183);
            Intro.WithDescription("Beachten Sie bitte, dass Sie nur die Commands anschauen können, für welche Sie die Berechtigung haben.");
            Intro.AddField("Commands", "`$help All` - Zeigt alle Commands, die Sie benutzen können\n" +
                "`$help User` - Zeigt alle Usercommand\n" +
                "`$help Team` - Zeigt alle Teamcommands\n" +
                "`$help Admin` - Zeigt alle Admincommands\n" +
                "`$help Besitzer` - Zeigt alle Besitzercommands");

            var Help = new EmbedBuilder();
            Help.WithTitle("Usercommands");
            Help.WithColor(103, 58, 183);
            Help.WithDescription("$calendar\n" +
                "$daily\n" +
                "$echo\n" +
                "$event\n" +
                "$Ihelp" +
                "$lvl\n" +
                "$profile\n" +
                "$setdob\n" +
                "$sethex\n" +
                "$setpp\n" +
                "$setpush\n" +
                "$setsex\n" +
                "$stats\n" +
                "$timer\n" +
                "$update\n" +
                "$xp\n" +
                "$zufall");

            var Team = new EmbedBuilder();
            Team.WithTitle("Teamcommands");
            Team.WithColor(103, 58, 183);
            Team.WithDescription("$setalpha\n" +
                "$setdoj\n" +
                "$setmember\n" +
                "$setr");

            var Admin = new EmbedBuilder();
            Admin.WithTitle("Admincommands");
            Admin.WithColor(103, 58, 183);
            Admin.WithDescription("$addpoints\n" +
                "$addXP\n");

            var Besitzer = new EmbedBuilder();
            Besitzer.WithTitle("Besitzercommands");
            Besitzer.WithColor(103, 58, 183);
            Besitzer.WithDescription("$setr");

            if (Command == "Help")
            {
                await Channel.SendMessageAsync("", embed: Intro.Build());
            }
            if (Command == "All" || Command == "User")
            {
                await Channel.SendMessageAsync("", embed: Help.Build());
            }
            if (Rights > 0 && (Command == "All" || Command == "Team"))
            {
                await Channel.SendMessageAsync("", embed: Team.Build());
            }
            if (Rights > 1 && (Command == "All" || Command == "Admin"))
            {
                await Channel.SendMessageAsync("", embed: Admin.Build());
            }
            if (Rights > 2 && (Command == "All" || Command == "Besitzer"))
            {
                await Channel.SendMessageAsync("", embed: Besitzer.Build());
            }
        }

        internal static async void DisplaySpecialHelp(ISocketMessageChannel Channel, string Value)
        {
            if (Value == "Inventory")
            {
                var Inventory = new EmbedBuilder();
                Inventory.WithTitle("Inventorycommands");
                Inventory.WithColor(103, 58, 183);
                Inventory.WithDescription("$accept\n" +
                    "$\n");
                await Channel.SendMessageAsync("", embed: Inventory.Build()); ;
                return;
            }
        }

        internal static void CommandHelp(string Command, ISocketMessageChannel Channel, SocketUser User)
        {
            int QGefunden = 0;
            var embed = new EmbedBuilder();
            string Title = "❓ | $" + Command;
            embed.WithTitle(Title);
            embed.WithColor(103, 58, 183);
            if (Command == "User" || Command == "All" || Command == "Team" || Command == "Admin" || Command == "Besitzer")
            {
                DisplayGuildHelp(Command, Channel, User);
                return;
            }
            else if (Command == "addpoints")
            {
                embed.WithDescription("Ändert die Punkte des Targets um die bestimmte Menge.");
                embed.AddField("Syntax", "`$addpoints {nPunkte} ({Target})`");
                embed.AddField("Berechtigung", "- Administrator");
            }
            else if (Command == "addxp")
            {
                embed.WithDescription("Ändert die XP des Targets um die bestimmte Menge.");
                embed.AddField("Syntax", "`addxp {XP} ({Target})`");
                embed.AddField("Berechtigung", "- Administrator");
            }
            else if (Command == "alpha")
            {
                embed.WithDescription("Lässt den Bot eine selbst gewählte Nachricht shouten.");
                embed.AddField("Syntax", "`$alpha {Nachricht}`");
                embed.AddField("Berechtigung", "- Alphamitglied");
            }
            else if (Command == "calendar")
            {
                embed.WithDescription("Zeigt Events im Radius von einem Monat um den derzeitigen oder gewählten.");
                embed.AddField("Syntax", "`$calendar ({Monat})`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "daily")
            {
                embed.WithDescription("Durch diesen Command können Sie einmal am Tag Geld einsammeln. Wenn Sie an aufeinanderfolgenden Tagen sammeln, erhöht sich Ihre Daily-Serie und Ihr Ertrag steigt. Am Monatsende wird die Serie resettet. Wenn Sie eine Woche am Stück sammeln, erhöht sich der Betrag permanent.");
                embed.AddField("Syntax", "`$daily`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "echo")
            {
                embed.WithDescription("Lässt den Bot einen Satz wiederholen.");
                embed.AddField("Syntax", "`$echo {Nachricht}`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "event")
            {
                embed.WithDescription("Claimt derzeitige Events und deren Belohnungen. Wann diese sind, kann man mit dem `$calendar`-Command herausfinden.");
                embed.AddField("Syntax", "`$event`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "help") // 
            {
                embed.WithDescription("Gibt Ihnen eine Übersicht der Commands oder eine kleine Erklärung dieser.");
                embed.AddField("Syntax", "1. `$help`\n2. `$help {Commandname}`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "helpI")
            {
                embed.WithDescription("Gibt Ihnen eine Übersicht über die Inventarbefehle.");
                embed.AddField("Syntax", "`$Ihelp`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "lvl")
            {
                embed.WithDescription("Zeigt, wie viel XP führ ein bestimmtes Level benötigt werden.");
                embed.AddField("Syntax", "`$lvl {Level}`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "profile")
            {
                embed.WithDescription("Zeigt Ihr Profil oder das eines anderen Users (des Targets).");
                embed.AddField("Syntax", "`$profile ({Target})`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "setalpha")
            {
                embed.WithDescription("Mit diesem Command können Sie die Alphaberechtigung eines Targets verändern.");
                embed.AddField("Syntax", "`$setalpha ({Target})`");
                embed.AddField("Berechtigung", "- Teammitglied");
            }
            else if (Command == "setdob")
            {
                embed.WithDescription("Durch diesen Command können Sie im TTMMJJJ-Format Ihr Geburtsdatum einstellen.");
                embed.AddField("Syntax", "`$setdob {Tag} {Monat} {Jahr}`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "setdoj")
            {
                embed.WithDescription("Durch diesen Command können Sie im TTMMJJJ-Format das Geburtsdatum eines Targets einstellen.");
                embed.AddField("Syntax", "`$setdoj {Tag} {Monat} {Jahr} ({Target})`");
                embed.AddField("Berechtigung", "- Teammitglied");
            }
            else if (Command == "sethex")
            {
                embed.WithDescription("Mit diesem Command können Sie die Farbe von, unter anderem, Ihrer Profil- und Stats-Nachricht im RGB Format einstellen.");
                embed.AddField("Syntax", "`$sethex {R} {G} {B}`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "setmember")
            {
                embed.WithDescription("Mit diesem Command können Sie die Memberberechtigung eines Targets verändern.");
                embed.AddField("Syntax", "`$sethex {Wert}`");
                embed.AddField("Berechtigung", "- Besitzer");
            }
            else if (Command == "setpp")
            {
                embed.WithDescription("Mit dem setpp-Befehl können Sie Ihr lokales Profilbild beliebig ändern. Sie können es auch einfach an Ihr globales oder an das Alpha-Symbol anpassen.");
                embed.AddField("Syntax", "1. $setpp {BildUrl}\n2. $setpp Pb\n3. $setpp Alpha");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "setpush")
            {
                embed.WithDescription("Ermöglicht es Ihnen, einige Benachrichtigungen auszuschalten. Der Wert `0` stellt die Nachrichten aus, der Wert `1` diese an.");
                embed.AddField("Syntax", "$setpush {Wert}");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "setsex")
            {
                embed.WithDescription("Mit diesem Commmand können Sie ihr Geschlecht in Ihr Profil eintragen.");
                embed.AddField("Syntax", "`$setsex {M/W}`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "setr")
            {
                embed.WithDescription("Mit diesem Command können Sie dem Target eine Bot-Restriction verpassen. Der Wert `0` ist Standard. Bei dem Wert `1` werden für das Target einige Commands gesperrt und bei Wert `2` der gesamte Bot.");
                embed.AddField("Syntax", "`$setr {Wert} {Target}`");
                embed.AddField("Berechtigung", "- Teammitglied\n- Besitzer");
            }
            else if (Command == "stats")
            {
                embed.WithDescription("Zeigt Ihre Stats oder die eines anderen Users (des Targets).");
                embed.AddField("Syntax", "`$stats ({Target})`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "timer")
            {
                embed.WithDescription("Mit dem Timer können Sie sich einen Wecker stellen. Nach dem Ablauf der Zeit werden Sie vom Bot benachrichtigt.");
                embed.AddField("Syntax", "`$timer {Minuten} ({Grund})`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "update")
            {
                embed.WithDescription("Durch diesen Command werden Profil- und Rolleneinstellungen synchronisiert. Also zum Beispiel die Alpha-Berechtigung und Geschlechtsrolle.");
                embed.AddField("Syntax", "`$update`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "xp")
            {
                embed.WithDescription("Durch diesen Command können Sie erfahren, welches Level bei einer bestimmeten Menge an XP erreicht wird.");
                embed.AddField("Syntax", "`$xp {XP}`");
                embed.AddField("Berechtigung", "-");
            }
            else if (Command == "zufall")
            {
                embed.WithDescription("Der Zufall-Command wählt aus bis zu 10 Items zufällig eins aus. Die jeweiligen Items müssen mit einem Trennstrich unterteilt werden.");
                embed.AddField("Syntax", "`$zufall {Item} | {Item} (...)`");
                embed.AddField("Berechtigung", "-");
            }
            /*
            else if (Command == "")
            {
                embed.WithDescription("");
                embed.AddField("Syntax", "a");
                embed.AddField("Berechtigung", "");                
            }
            */
            else
            {
                QGefunden = 1;
                Channel.SendMessageAsync($"{Utilities.GetAlert("ONo")} Der Command konnte nicht gefunden werden. Schreiben Sie bitte alles in Kleinbuchstaben" + ". Syntax: `$help {Command}`");
            }

            if (QGefunden == 0)
            {
                Channel.SendMessageAsync("", embed: embed.Build());
            }
        }
    }
}
