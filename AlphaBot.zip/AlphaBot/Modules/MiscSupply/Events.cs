﻿using AlphaBot.DataManagement.UserAccountsFolder;
using Discord.WebSocket;


namespace AlphaBot.Modules.MiscSupply
{
    internal static class Events
    {
        internal static string MonthDisplay(int Month)
        {
            string MonthContent = "";

            if (Month == 1)
            {
                MonthContent = "03. 🎆 Neujahr (Ende)";
            }
            else if (Month == 2)
            {
                MonthContent = "Keine Events eingetragen";
            }
            else if (Month == 3)
            {
                MonthContent = "Keine Events eingetragen";
            }
            else if (Month == 4)
            {
                MonthContent = "16. 🐇 Ostern\n"
                    + "26. 🐇 Ostern (Ende)";
            }
            else if (Month == 5)
            {
                MonthContent = "Keine Events eingetragen";
            }
            else if (Month == 6)
            {
                MonthContent = "Keine Events eingetragen";
            }
            else if (Month == 7)
            {
                MonthContent = "29. 🌞 Sommer";
            }
            else if (Month == 8)
            {
                MonthContent = "Keine Events eingetragen";
            }
            else if (Month == 9)
            {
                MonthContent = "10. 🌞 Sommer (Ende)";
            }
            else if (Month == 10)
            {
                MonthContent = "27. 🎃 Halloween";
            }
            else if (Month == 11)
            {
                MonthContent = "05. 🎃 Halloween (Ende)";
            }
            else if (Month == 12)
            {
                MonthContent = "20. 🎉 GB - AsderGaming\n"
                    + "28. 🎆 Neujahr";
            }
            return MonthContent;
        }

        internal static async void EventClaimer(SocketUser user, int Month, int Day, ISocketMessageChannel Channel)
        {
            var account = UserAccounts.GetOrCreateAccount(user.Id);

            int FirstFR = account.TimeEvent % 10;
            int SecondFR = account.TimeEvent % 100;
            SecondFR -= FirstFR;
            SecondFR /= 10;
            int ThirdFR = account.TimeEvent % 1000;
            ThirdFR -= (FirstFR + SecondFR);
            ThirdFR /= 100;
            int FourthFR = account.TimeEvent & 10000;
            FourthFR -= (FirstFR + SecondFR + ThirdFR);
            FourthFR /= 1000;

            if (Month == 12 && Day > 27 || Month == 1 && Day < 4)
            {
                if (FirstFR != 1) // Neujahr
                {
                    account.Points += 1;
                    account.TimeEvent += 1;
                    account.Currency += 100;
                    await Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Sie haben ein neues Badge, einen Punkt und 150€ bekommen!");
                }
                else if (FirstFR == 1)
                {
                    await Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Sie haben sich Ihre Belohnung schon abgeholt!");
                }
            }
            else if (Month == 4 && Day > 15 && Day < 27)
            {
                if (SecondFR != 1) // Ostern
                {
                    account.TimeEvent += 10;
                    account.Points += 1;
                    account.Currency += 100;
                    await Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Sie haben ein neues Badge, einen Punkt und 100€ bekommen!");
                }
                else if (SecondFR == 1)
                {
                    await Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Sie haben sich Ihre Belohnung schon abgeholt!");
                }
            }
            else if (Month == 7 && Day > 28 || Month == 9 && Day < 11)
            {
                if (ThirdFR != 1) // Sommer
                {
                    account.TimeEvent += 100;
                    account.Points += 1;
                    account.Currency += 100;
                    await Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Sie haben ein neues Badge, einen Punkt und 75€ bekommen!");
                }
                else if (ThirdFR == 1)
                {
                    await Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Sie haben sich Ihre Belohnung schon abgeholt!");
                }
            }
            else if (Month == 10 && Day > 26 || Month == 11 && Day < 5)
            {
                if (FourthFR != 1) // Halloween
                {
                    account.TimeEvent += 1000;
                    account.Points += 1;
                    account.Currency += 100;
                    await Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Sie haben ein neues Badge, einen Punkt und 111€ bekommen!");
                }
                else if (FourthFR == 1)
                {
                    await Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Sie haben sich Ihre Belohnung schon abgeholt!");
                }
            }
            else
            {
                await Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Es ist zurzeit kein Spezialevent aktiv.");
            }

        }

        internal static string BadgeProcess(int TimeEvent)
        {
            string Event = "";
            if (TimeEvent != 0)
            {

                int FirstFR = TimeEvent % 10;
                int SecondFR = TimeEvent % 100;
                SecondFR -= FirstFR;
                SecondFR /= 10;
                int ThirdFR = TimeEvent % 1000;
                ThirdFR -= (FirstFR + SecondFR);
                ThirdFR /= 100;
                int FourthFR = TimeEvent & 10000;
                FourthFR -= (FirstFR + SecondFR + ThirdFR);
                FourthFR /= 1000;

                if (FirstFR == 1) // Neujahr
                {
                    Event = "🎆";
                }
                if (SecondFR == 1)
                {
                    Event += "🐇"; // Ostern
                }
                if (ThirdFR == 1)
                {
                    Event += "🌞"; // Sommer
                }
                if (FourthFR == 1)
                {
                    Event += "🎃"; // Halloween
                }
            }
            else
            {
                Event = "";
            }
            return Event;
        }
    }
}
