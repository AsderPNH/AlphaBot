﻿using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace AlphaBot.ZSystem
{
    class ErrorHandler
    {
        internal static string LastSystemErrorCache { get; set; }
        internal static byte SystemErrorCache { get; set; }       

        internal static void CatchError(string errorCode, [CallerLineNumber] int lineNumber = 0, [CallerMemberName] string caller = "", [CallerFilePath] string path = "")
        {
            if (LastSystemErrorCache == errorCode) SystemErrorCache += 1; // caching
            else SystemErrorCache = 0;
            LastSystemErrorCache = errorCode;

            int indexOfLastBackslash = path.LastIndexOf('\\'); // getting the FileName
            int indexOfLastPoint = path.LastIndexOf('.');
            path = path.Substring(indexOfLastBackslash + 1, (indexOfLastPoint - indexOfLastBackslash) - 1);

            System.Console.WriteLine($"catchedError | {errorCode} | {path}, {caller}(), line {lineNumber}"); // output in Console
            if (SystemErrorCache < (Config.bot.error_CacheLimit + 1)) // output in VirtualConsole
            { 
                VirtualConsole.SendImportantLog($"catchedError | {errorCode} | {path}, {caller}(), line {lineNumber}");  // output with caller and path info
            } 
        }  
        
        internal static Task ClearErrorCache()
        {
            LastSystemErrorCache = null;
            SystemErrorCache = 0;
            return Task.CompletedTask;
        }
    }
}
