﻿using Discord;
using Discord.WebSocket;
using System;
using System.Threading.Tasks;

namespace AlphaBot.ZSystem
{
    internal class VirtualConsole
    {
        internal static async Task Log(LogMessage msg) // log
        {
            if (Program.BotIsReady == false)
            {
                Console.WriteLine(msg.Message); // only SystemConsole if bot isn't ready
            }
            else // if ready
            {
                if (msg.Message.Contains("POST") // excluded strings
                    || msg.Message.Contains("Received Dispatch")
                    || msg.Message.Contains("Sent Heartbeat")
                    || msg.Message.Contains("Received HeartbeatAck")) { Console.WriteLine(msg.Message); } // only SystemConsole if <msg> contains <excludedString>
                else if (Program.BotIsReady == true) await SendCasualLog($"log | {msg.Message}");
            }
            if (msg.Message == "Ready")
            {
                await Program.OnBotIsReady();
                Program.BotIsReady = true;
            }
        }

        internal static Task SendImportantLog(string log)
        {
            var channel = Global.Client.GetGuild(Config.bot.guild_main).GetTextChannel(Config.bot.channel_vConsole_important);
            
            channel.SendMessageAsync(log);
            Console.WriteLine(log);

            return Task.CompletedTask;
        }        

        internal static Task SendCasualLog(string log)
        {
            var channel = Global.Client.GetGuild(Config.bot.guild_main).GetTextChannel(Config.bot.channel_vConsole_casual);

            channel.SendMessageAsync(log);
            Console.WriteLine(log);

            return Task.CompletedTask;
        }        
    }
}
