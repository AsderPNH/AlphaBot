﻿using AlphaBot.DataManagement.UserAccountsFolder;
using System;
using System.Threading.Tasks;
using System.Timers;


namespace AlphaBot.ZSystem
{
    class DayCheck
    {
        private static Timer loopingTimer;
        private static UserAccount bot;
        internal static Task StartTimer()
        {
            bot = UserAccounts.GetOrCreateAccount(Config.bot.bot_ID); // get userAccount of bot

            loopingTimer = new Timer()
            {
                Interval = 60000,
                AutoReset = true,
                Enabled = true
            };
            loopingTimer.Elapsed += CheckDate;
            return Task.CompletedTask;
        }

        private static async void CheckDate(object sender, ElapsedEventArgs e)
        {
            if (bot.DateOfBirth.Day != DateTime.Now.Day) await OnNewDay(); // if day has changed since last check
        }

        private static async Task OnNewDay()
        {
            if (bot.DateOfBirth.Month != DateTime.Now.Month) await OnNewMonth(); // if month has changed since last check

            await Backup.AutoBackup(); // Triggering the autoBackup
            bot.DateOfBirth = DateTime.Now; // updating the "LastSuccessfullDayCheck"-DateTime
            UserAccounts.SaveAccounts(); // saving the most recent change            
        }

        private static async Task OnNewMonth()
        {
            await Backup.DeleteFiles(DateTime.Now); // Deleting two-months-old backups
        }
    }
}
