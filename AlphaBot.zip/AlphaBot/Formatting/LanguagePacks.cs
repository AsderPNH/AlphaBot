﻿using System;
using System.IO;
using System.Collections.Generic;
using Discord.WebSocket;
using Newtonsoft.Json;


using AlphaBot.DataManagement.ServerAccountsFolder;
using AlphaBot.DataManagement.UserAccountsFolder;
using Discord.Commands;

namespace AlphaBot.Formatting
{
    class LanguagePacks
    {
        //private static Dictionary<string, string> languageLocal;
        internal static bool LanguageFilesAvailable { get; set; }

        //--//
        private static Dictionary<string, Dictionary<string, string>> languages = new Dictionary<string, Dictionary<string, string>>(); 
        //--//

        //--//
        private static Dictionary<string, string> GetLanguage(string language) 
        {
            // checks, if files are available
            if (LanguageFilesAvailable == false)
            {
                ZSystem.ErrorHandler.CatchError("ERROR1");
                return null;
            }            

            if (languages.ContainsKey(language)) // if language is already deserialized
            {
                return languages[language]; // return language
            }
            else // deserialize and save language
            {
                // deserializes specific language file
                string json = File.ReadAllText($"Formatting/SystemLang/{language}.json");
                var data = JsonConvert.DeserializeObject<dynamic>(json);
                Dictionary<string, string> newLanguage = data.ToObject<Dictionary<string, string>>();
                languages.Add(language, newLanguage);
                return newLanguage;
            }
        }
        //--//

        /*private LanguagePacks(string language)
        {
            // checks, if files are available
            if (LanguageFilesAvailable == false) 
            { 
                ZSystem.ErrorHandler.CatchError("ERROR1"); 
                return; 
            } 

            // deserializes specific language file
            string json = File.ReadAllText($"Formatting/SystemLang/{language}.json");
            var data = JsonConvert.DeserializeObject<dynamic>(json);
            languageLocal = data.ToObject<Dictionary<string, string>>();
        }*/

        // chooses, which language should be used
        private static string ChooseLanguage(string languagePriority, string languageOptional)
        {
            if (languagePriority == null)
            {
                return languageOptional;
            }
            return languagePriority;
        }
        private static string ChooseLanguage(SocketUser user, SocketGuild guild)
        {
            var userAccount = UserAccounts.GetUserAccount(user);
            var serverAccount = ServerAccounts.GetServerAccount(guild);
            return ChooseLanguage(userAccount.Language, serverAccount.ServerLanguage);
        }
        

        // checks, if language-file exists
        internal static bool LanguageExists(string language)
        {
            language = language.ToLower();
            if (!File.Exists($"Formatting/SystemLang/{language}.json")) return false;
            return true;
        }

        //--//
        // gets sentence 
        internal static string GetSentence(string hiddenFileName, string key) 
        {
            Dictionary<string, string> language = GetLanguage(hiddenFileName);
            if (language.ContainsKey(key)) return language[key];
            return "";
        }
        internal static string GetSentence(string languagePriority, string languageOptional, string key)
        {
            string languageChosen = ChooseLanguage(languagePriority, languageOptional);
            return GetSentence(languageChosen, key);
        }
        internal static string GetSentence(SocketUser user, SocketGuild guild, string key) //// delete
        {
            var userAccount = UserAccounts.GetUserAccount(user);
            var serverAccount = ServerAccounts.GetServerAccount(guild);
            return GetSentence(userAccount.Language, serverAccount.ServerLanguage, key);
        }
        internal static string GetSentence(SocketCommandContext context, string key)
        {
            var userAccount = UserAccounts.GetUserAccount(context.User);
            var serverAccount = ServerAccounts.GetServerAccount(context.Guild);
            return GetSentence(userAccount.Language, serverAccount.ServerLanguage, key);
        }
        //--//

        /* gets sentence 
        internal static string GetSentence(string hiddenFileName, string key)
        {
            new LanguagePacks(hiddenFileName);
            if (languageLocal.ContainsKey(key)) return languageLocal[key];
            return "";
        }
        internal static string GetSentence(string languagePriority, string languageOptional, string key)
        {
            string languageChosen = ChooseLanguage(languagePriority, languageOptional);
            new LanguagePacks(languageChosen);
            if (languageLocal.ContainsKey(key)) return languageLocal[key];
            return "";
        }
        internal static string GetSentence(SocketUser user, SocketGuild guild, string key)
        {
            var userAccount = UserAccounts.GetUserAccount(user);
            var serverAccount = ServerAccounts.GetServerAccount(guild);
            return GetSentence(userAccount.Language, serverAccount.ServerLanguage, key);
        }*/

        //--//
        // gets sentence with formatted string (1 extra parameter)
        public static string GetFormattedSentence(string hiddenFileName, string key, object parameter)
        {
            return GetFormattedSentence(hiddenFileName, key, new object[] { parameter });
        }
        public static string GetFormattedSentence(string languagePriority, string languageOptional, string key, object parameter)
        {
            return GetFormattedSentence(languagePriority, languageOptional, key, new object[] { parameter });
        }
        public static string GetFormattedSentence(SocketUser user, SocketGuild guild, string key, object parameter) //// delete
        {
            var userAccount = UserAccounts.GetUserAccount(user);
            var serverAccount = ServerAccounts.GetServerAccount(guild);
            return GetFormattedSentence(userAccount.Language, serverAccount.ServerLanguage, key, new object[] { parameter });
        }
        public static string GetFormattedSentence(SocketCommandContext context, string key, object parameter)
        {
            var userAccount = UserAccounts.GetUserAccount(context.User);
            var serverAccount = ServerAccounts.GetServerAccount(context.Guild);
            return GetFormattedSentence(userAccount.Language, serverAccount.ServerLanguage, key, new object[] { parameter });
        }
        //--//

        /* gets sentence with formatted string (1 extra parameter)
        public static string GetFormattedSentence(string hiddenFileName, string key, object parameter)
        {
            return GetFormattedSentence(hiddenFileName, key, new object[] { parameter });
        }
        public static string GetFormattedSentence(string languagePriority, string languageOptional, string key, object parameter)
        {
            return GetFormattedSentence(languagePriority, languageOptional, key, new object[] { parameter });
        }
        public static string GetFormattedSentence(SocketUser user, SocketGuild guild, string key, object parameter)
        {
            var userAccount = UserAccounts.GetUserAccount(user);
            var serverAccount = ServerAccounts.GetServerAccount(guild);
            return GetFormattedSentence(userAccount.Language, serverAccount.ServerLanguage, key, new object[] { parameter });
        }*/

        //--//
        // gets sentence with formatted string (multiple extra parameters)
        public static string GetFormattedSentence(string hiddenFileNameOrChosenLanguage, string key, params object[] parameter)
        {
            Dictionary<string, string> language = GetLanguage(hiddenFileNameOrChosenLanguage);
            if (language.ContainsKey(key))
            {
                return String.Format(language[key], parameter);
            }
            return "";
        }
        public static string GetFormattedSentence(string languagePriority, string languageOptional, string key, params object[] parameter)
        {
            string languageChosen = ChooseLanguage(languagePriority, languageOptional);
            return GetFormattedSentence(languageChosen, key, parameter);
        }
        public static string GetFormattedSentence(SocketUser user, SocketGuild guild, string key, params object[] parameter) //// delete
        {
            var userAccount = UserAccounts.GetUserAccount(user);
            var serverAccount = ServerAccounts.GetServerAccount(guild);
            return GetFormattedSentence(userAccount.Language, serverAccount.ServerLanguage, key, parameter);
        }
        public static string GetFormattedSentence(SocketCommandContext context, string key, params object[] parameter)
        {
            var userAccount = UserAccounts.GetUserAccount(context.User);
            var serverAccount = ServerAccounts.GetServerAccount(context.Guild);
            return GetFormattedSentence(userAccount.Language, serverAccount.ServerLanguage, key, parameter);
        }
        //--//

        /* gets sentence with formatted string (multiple extra parameters)
        public static string GetFormattedSentence(string hiddenFileName, string key, params object[] parameter)
        {
            new LanguagePacks(hiddenFileName);
            if (languageLocal.ContainsKey(key))
            {
                return String.Format(languageLocal[key], parameter);
            }
            return "";
        }
        public static string GetFormattedSentence(string languagePriority, string languageOptional, string key, params object[] parameter)
        {
            string languageChosen = ChooseLanguage(languagePriority, languageOptional);
            new LanguagePacks(languageChosen);
            if (languageLocal.ContainsKey(key))
            {
                return String.Format(languageLocal[key], parameter);
            }
            return "";
        }
        public static string GetFormattedSentence(SocketUser user, SocketGuild guild, string key, params object[] parameter)
        {
            var userAccount = UserAccounts.GetUserAccount(user);
            var serverAccount = ServerAccounts.GetServerAccount(guild);
            return GetFormattedSentence(userAccount.Language, serverAccount.ServerLanguage, key, parameter);
        }*/
    }
}
