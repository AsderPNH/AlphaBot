﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlphaBot.ZTools
{
    class CommandErrorHandler
    {
    }
}
