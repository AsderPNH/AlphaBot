﻿using System.IO;
using Discord;
using Newtonsoft.Json;

namespace AlphaBot
{
    class Config
    {
        private const string configFolder = "Resources";
        private const string configFile = "config.json";

        public static BotConfig bot;

        static Config()
        {
            if (!Directory.Exists(configFolder))
            {
                Directory.CreateDirectory(configFolder);
            }

            if (!File.Exists(configFolder + "/" + configFile))
            {
                bot = new BotConfig();
                string json = JsonConvert.SerializeObject(bot, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(configFolder + "/" + configFile, json);
            }
            else
            {
                string json = File.ReadAllText(configFolder + "/" + configFile);
                bot = JsonConvert.DeserializeObject<BotConfig>(json);
            }
        }
    }

    public struct BotConfig
    {
        public string bot_version;
        public string bot_token;
        public ulong bot_ID;
        public string bot_Admins;

        public ulong guild_main;
        public string guild_default_language;
        public string guild_default_prefix;

        public ulong channel_vConsole_important;
        public ulong channel_vConsole_casual;

        public byte error_CacheLimit;
        public string userAccount_default_profilepicture;
        public byte userAccount_commandsUsed_lowBorder;
        public byte userAccount_unknownCommandsWhileAutoPrefix_limit;
    }
}
