﻿using System;
using System.Linq;
using Discord.WebSocket;

using AlphaBot.DataManagement.ServerAccountsFolder;


namespace AlphaBot.Core.LocalPermissionFolder
{
    class LocalPermission
    {
        internal static bool HasLocalPermission(SocketGuildUser user)
        {            
            ServerAccount serverAccount = ServerAccounts.GetServerAccount(user.Guild);

            foreach(SocketRole role in user.Roles) // checks each role of the user
            {
                if (role.Permissions.Administrator) return true; // if any role has admin permission -> true
            }

            string[] admins = serverAccount.ServerAdmins.Split('|'); // <string[]> of the local WhiteList

            if (admins.Contains(user.Id.ToString()) == true) return true; // if WhiteList contains userId

            foreach (string admin in admins) // checks each WhiteList-slot
            {                
                if (admin[0] == 'r') // if WhiteList-slot starts with 'r' (= localBotAdminRoleId)
                {                    
                    string newAdmin = admin.Remove(0,1); // removes 'r'

                    foreach(SocketRole role in user.Roles) // checks each role of the user
                    {
                        if (role.Id.ToString() == newAdmin) return true; // if roleId is localBotAdminRoleId
                    }
                }                
            }
            return false; // else -> false
        }
    }
}
