﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlphaBot.Core.InventorySystem
{
    internal static class Items
    {
        internal static int HighestID()
        {
            return 4;
        }

        internal static string LookUpNameEmoteRarityWorthSpecial(int Id, int Wanted)
        {
            // 1 - 200 = Wertgegenstände
            // 201 - 300 = Kleidung
            // 301 - 500 = Waffen
            // 501 - 600 = Essen            

            // Common - Worth: 3
            // Uncommon - Worth: 5
            // Rare - Worth: 10
            // Epic - Worth: 25

            string Name = "";
            string Emote = "";
            string Rarity = "";
            int Worth = 0;
            string Special = "";
            if (Id == 1)
            {
                Name = "CD";
                Emote = "💿";
                Rarity = "Common";
            }
            else if (Id == 2)
            {
                Name = "DVD";
                Emote = "📀";
                Rarity = "Uncommon";
            }
            else if (Id == 3)
            {
                Name = "BluRay";
                Emote = "💿";
                Rarity = "Rare";
            }
            else if (Id == 4)
            {
                Name = "Schallplatte";
                Emote = "📀";
                Rarity = "Epic";
            }
            else if (Id == 5)
            {
                Name = "";
                Emote = "";
                Rarity = "";
            }
            else if (Id == 6)
            {
                Name = "";
                Emote = "";
                Rarity = "";
            }
            else if (Id == 7)
            {
                Name = "";
                Emote = "";
                Rarity = "";
            }
            else if (Id == 8)
            {
                Name = "";
                Emote = "";
                Rarity = "";
            }
            else if (Id == 9)
            {
                Name = "";
                Emote = "";
                Rarity = "";
            }
            else if (Id == 10)
            {
                Name = "";
                Emote = "";
                Rarity = "";
            }
            /*
            else if (Id ==)
            {
                Name = "";
                Emote = "";
                Rarity = "";
            }*/

            if (Worth == 0)
            {
                if (Rarity == "Common")
                {
                    Worth = 3;
                }
                else if (Rarity == "Uncommon")
                {
                    Worth = 5;
                }
                else if (Rarity == "Rare")
                {
                    Worth = 10;
                }
                else if (Rarity == "Epic")
                {
                    Worth = 25;
                }
            }

            if (Wanted == 1)
            {
                return Name;
            }
            else if (Wanted == 2)
            {
                return Emote;
            }
            else if (Wanted == 3)
            {
                return Rarity;
            }
            else if (Wanted == 4)
            {
                return Worth.ToString();
            }
            else
            {
                return Special;
            }
        }
    }
}
