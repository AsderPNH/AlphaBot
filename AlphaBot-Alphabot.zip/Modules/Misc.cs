﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using Discord;
using Discord.Commands;
using Discord.Rest;
using Discord.WebSocket;

using AlphaBot.Formatting;
using AlphaBot.Core.InventorySystem;


using AlphaBot.DataManagement.ServerAccountsFolder;

using AlphaBot.Modules.MiscSupply;
using AlphaBot.Modules.MiscSupply.BotAdminSupply;
using AlphaBot.Modules.MiscSupply.ProfileSupply;

using AlphaBot.ZSystem;
using AlphaBot.DataManagement.UserAccountsFolder;

namespace AlphaBot.Modules
{
    /*
    --------
    -<> Bei RandomItemGen Geld geben, wenn der User das Item schon besitzt
    - AlphaBot PB (Wolf)     
    - Stunden bei Timer?
    - Allgemeine TextOutputs
    - HelpListe aktualisieren
      - Iaccept
      - Isell
      - Itrade
      - Ibuy
      - Icheckcount
      - Itrades
      - Istored
      - Iset strict
      - setpush
      - Inventory
      - Item  
    - Inventory          
      - Ideny    
      - Sobald einer Storen anhat, wird gestoret
    */

    public class Misc : ModuleBase<SocketCommandContext>
    {
        [Command("test")]
        public async Task Test()
        {
            int Id = IFunctions.ItemGenFull(WorthClothingWeaponFood: 1, Percent: 100, Kinds: 4, Multiplier: 2, User: Context.User);
            IFunctions.AddItem(Id, 1, Context.User);
        }

        [Command("test2")] // ShowInv
        public async Task Test2()
        {
            IFunctions.ShowInv(Context.Channel, Context.User);
            await Context.Channel.SendMessageAsync("Fertig2");
        }

        [Command("test3")] // Clear
        public async Task Test3()
        {
            var account = UserAccounts.GetUserAccount(Context.User);
            account.Username = Context.User.Username;
            await Context.Channel.SendMessageAsync(account.Username);
        }

        [Command("test4")]
        public async Task Test4()
        {
            Pasting.Eingangshalle(Context.Channel);
        }

        [Command("test5")]
        public async Task Test5()
        {
            //await Context.Channel.SendMessageAsync(Config.bot.language_default); // eng
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            await Context.Channel.SendMessageAsync(LanguagePacks.GetSentence("eng", "deu", "TEST")); // engliiiisch / deutsch halt
            await Context.Channel.SendMessageAsync(LanguagePacks.GetSentence("deu", "deu", "TEST")); // deutsch halt
            /*await Context.Channel.SendMessageAsync(Formatting.LanguagePacks.GetSentence("deu", "eng", "TEST"));*/
        }

        // BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB

        [Command("signUp")]
        public async Task SignUp()
        {
            await ProfilePrivacy.SignUp(Context);
        }



        [Command("b backup")]
        public async Task ForceBackup()
        {
            await Backup.ForcedBackup(); // manual backup
        }
        [Command("b ?lastBackup")]
        public async Task GetLastBackupInfo()
        {
            await Backup.GetLastBackupInfo(Context);
        }
        [Command("b filesAvailable:")]
        public async Task SetFilesStatus(bool status)
        {
            await Backup.SetFilesStatus(status, Context); // disables/enables files
        }
        [Command("b ?filesAvailable")]
        public async Task GetFilesStatus()
        {
            await Backup.GetFilesStatus(Context); // gets info about FileStatus
        }
        [Command("b clearErrorCache")]
        public async Task ClearErrorCache()
        {
            await ErrorHandler.ClearErrorCache(); // clears ErrorCache
        }



        [Command("a addAdmin")]
        public async Task SetLocalAdmin([Remainder] string remainder)
        {
            await Modules.MiscSupply.ServerAdminSupply.ServerSettings.SetLocalAdmin(remainder, Context);
        }
        [Command("a clearAdmin")]
        public async Task ClearAdmins()
        {
            await Modules.MiscSupply.ServerAdminSupply.ServerSettings.ClearAdmins(Context);
        }
        [Command("a addBotchannel")] [Alias("a addBotchannels")]
        public async Task SetBotchannel([Remainder] string remainder)
        {
            await Modules.MiscSupply.ServerAdminSupply.ServerSettings.SetBotchannel(remainder, Context);
        }
        [Command("a clearBotchannel")] [Alias("a clearBotchannels")]
        public async Task ClearBotchannels()
        {
            await Modules.MiscSupply.ServerAdminSupply.ServerSettings.ClearBotchannels(Context);
        }
        [Command("a setPrefix")]
        public async Task SetPrefix(string prefix)
        {
            await Modules.MiscSupply.ServerAdminSupply.ServerSettings.SetPrefix(prefix, Context);
        }
        [Command("a skipDialogue")]
        public async Task SkipDialogue()
        {
            await Modules.MiscSupply.ServerAdminSupply.GuildDialogue.SkipDialogue(Context.Guild);
        }



        [Command("p language")] [Alias("p lang", "p l")]
        public async Task SetLanguage(string language)
        {
            await Modules.MiscSupply.ProfileSupply.ProfileLanguage.SetLanguage(language, Context); // sets <language> as userLanguage
        }
        [Command("p autoPrefix")] [Alias("p a")]
        public async Task SetAutoPrefix()
        {
            await Modules.MiscSupply.ProfileSupply.AutoPrefix.SetAutoPrefix("", Context);
        }
        [Command("p autoPrefix")] [Alias("p a")]
        public async Task SetAutoPrefix([Remainder] string remainder)
        {
            await Modules.MiscSupply.ProfileSupply.AutoPrefix.SetAutoPrefix(remainder, Context);
        }



        [Command("help")] [Alias("h")]
        public async Task HelpDisplay()
        {
            await MiscSupply.HelpSupply.Help.GeneralHelp(Context);
            //Help.DisplayHelp(Context.Channel, Context.User);
        }
        [Command("help")] [Alias("h")]
        public async Task HelpDisplay([Remainder]string command)
        {
            await MiscSupply.HelpSupply.Help.CommandHelp(command, Context);
            //Help.CommandHelp(command, Context.Channel, Context.User);
        }

        // AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

        [Command("addpoints")] // AdminCommand - Punkte geben
        [RequireUserPermission(GuildPermission.Administrator)]
        public async Task AddXPoints(int points)
        {
            SocketUser target = null;
            var mentionedUser = Context.Message.MentionedUsers.FirstOrDefault();
            target = mentionedUser ?? Context.User;
            var account = UserAccounts.GetOrCreateAccount(target.Id);

            account.Points += points;
            UserAccounts.SaveAccounts();

            await Context.Channel.SendMessageAsync($"<:Plus:539237156363698187> | Punkte erfolgreich um {points} verändert.");
        }
        [Command("addXP")] // AdminCommand - XP geben
        [RequireUserPermission(GuildPermission.Administrator)]
        public async Task AddXP(uint xp)
        {
            SocketUser target = null;
            var mentionedUser = Context.Message.MentionedUsers.FirstOrDefault();
            target = mentionedUser ?? Context.User;
            var account = UserAccounts.GetOrCreateAccount(target.Id);

            account.XP += xp;
            UserAccounts.SaveAccounts();

            await Context.Channel.SendMessageAsync($"<:Plus:539237156363698187> | XP erfolgreich um {xp} verändert.");
        }
        [Command("alpha")] // Alpha-Shout
        public async Task Alpha([Remainder] string message)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (account.Alpha < 1)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetFormattedAlert("ERROR_PERMISSION_&REASON", "Sie müssen Alphamitglied sein, um ihn zu nutzen."));
                return;
            }
            string username = Context.User.Username;

            var embed = new EmbedBuilder();
            embed.WithTitle(Utilities.GetAlert("Projekt ΛLPHΛ"));
            embed.WithDescription($"**{username}**\n...ist ein Alpha!:\n\n\"{message}\"");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/471249140215447562/520712420126228480/1.221.jpg");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        // BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB



        // CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

        [Command("calendar")] // Events anzeigen      
        public async Task ShowEvents()
        {
            int Month = Context.Message.CreatedAt.Month;
            int PastMonthInt = Month - 1;
            if (PastMonthInt == 0)
            {
                PastMonthInt = 12;
            }
            int FutureMonthInt = Month + 1;
            if (FutureMonthInt == 13)
            {
                FutureMonthInt = 1;
            }
            String PastMonth = Events.MonthDisplay(PastMonthInt);
            String CurrentMonth = Events.MonthDisplay(Month);
            String FutureMonth = Events.MonthDisplay(FutureMonthInt);

            var embed2 = new EmbedBuilder();
            embed2.WithTitle("Kalender");
            embed2.WithDescription("Falls Sie Ihren Geburtstag eingetragen haben möchten, müssen Sie auf ein Teammitglied zugehen.");
            embed2.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/540486276051369995/calendar_1f4c5.png");
            embed2.WithCurrentTimestamp();
            embed2.WithColor(new Color(250, 250, 250));
            await Context.Channel.SendMessageAsync("", embed: embed2.Build());

            var embed = new EmbedBuilder();
            embed.WithTitle($"{PastMonthInt} | Letzter Monat");
            embed.WithDescription(PastMonth);
            embed.WithColor(new Color(244, 67, 54));
            await Context.Channel.SendMessageAsync("", embed: embed.Build());

            embed.WithTitle($"{Month} | Jetziger Monat");
            embed.WithDescription(CurrentMonth);
            embed.WithColor(new Color(0, 191, 255));
            await Context.Channel.SendMessageAsync("", embed: embed.Build());

            embed.WithTitle($"{FutureMonthInt} | Nächster Monat");
            embed.WithDescription(FutureMonth);
            embed.WithColor(new Color(76, 175, 80));
            await Context.Channel.SendMessageAsync("", embed: embed.Build());
        }
        [Command("calendar")] // Events anzeigen (für bestimmten Monat)      
        public async Task ShowEventsDefined(int month, [Remainder] string arg = "")
        {
            if (month < 1 || month > 12)
            {
                await Context.Channel.SendMessageAsync($"{Utilities.GetAlert("OError")}");
                return;
            }
            int Month = month;
            int PastMonthInt = Month - 1;
            if (PastMonthInt == 0)
            {
                PastMonthInt = 12;
            }
            int FutureMonthInt = Month + 1;
            if (FutureMonthInt == 13)
            {
                FutureMonthInt = 1;
            }
            String PastMonth = Events.MonthDisplay(PastMonthInt);
            String CurrentMonth = Events.MonthDisplay(Month);
            String FutureMonth = Events.MonthDisplay(FutureMonthInt);

            var embed2 = new EmbedBuilder();
            embed2.WithTitle("Kalender");
            embed2.WithDescription("Falls Sie Ihren Geburtstag eingetragen haben möchten, müssen Sie auf ein Teammitglied zugehen.");
            embed2.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/540486276051369995/calendar_1f4c5.png");
            embed2.WithCurrentTimestamp();
            embed2.WithColor(new Color(250, 250, 250));
            await Context.Channel.SendMessageAsync("", embed: embed2.Build());

            var embed = new EmbedBuilder();
            embed.WithTitle($"{PastMonthInt} | Vorheriger Monat");
            embed.WithDescription(PastMonth);
            embed.WithColor(new Color(244, 67, 54));
            await Context.Channel.SendMessageAsync("", embed: embed.Build());

            embed.WithTitle($"{Month} | Gewählter Monat");
            embed.WithDescription(CurrentMonth);
            embed.WithColor(new Color(0, 191, 255));
            await Context.Channel.SendMessageAsync("", embed: embed.Build());

            embed.WithTitle($"{FutureMonthInt} | Folgender Monat");
            embed.WithDescription(FutureMonth);
            embed.WithColor(new Color(76, 175, 80));
            await Context.Channel.SendMessageAsync("", embed: embed.Build());
        }

        // DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

        [Command("daily")]
        public async Task ClaimDaily()
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            double CurrencyPlus = 10 + (account.NDailySeries + account.NDailyPermanentSeries) * 5;
            int NDailySeriesFirst = account.NDailySeries;
            int NDailyPermanentSeriesFirst = account.NDailyPermanentSeries;
            if (account.TLastDaily == Context.Message.CreatedAt.Day)
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Sie haben Ihre Tagesbelohnung heute schon eingesammelt.");
                return;
            }
            else if (Context.Message.CreatedAt.Day != account.TLastDaily + 1 && account.TLastDaily != 0)
            {
                account.NDailySeries = 0;
            }
            else if (account.TLastDaily == 0 || Context.Message.CreatedAt.Day == account.TLastDaily + 1)
            {
                account.NDailySeries += 1;
            }

            if (NDailySeriesFirst > 0 && account.NDailySeries == 0)
            {
                if (NDailySeriesFirst >= 28)
                {
                    account.NDailyPermanentSeries += 4;
                }
                else
                {
                    if (NDailySeriesFirst >= 21)
                    {
                        account.NDailyPermanentSeries += 3;
                    }
                    else
                    {
                        if (NDailySeriesFirst >= 14)
                        {
                            account.NDailyPermanentSeries += 2;
                        }
                        else
                        {
                            if (NDailySeriesFirst >= 7)
                            {
                                account.NDailyPermanentSeries += 1;
                            }
                        }
                    }
                }
            }
            account.Currency += CurrencyPlus;
            account.TLastDaily = Convert.ToByte(Context.Message.CreatedAt.Day);
            if (NDailyPermanentSeriesFirst != account.NDailyPermanentSeries)
            {
                int PermanentSeriesDiff = account.NDailyPermanentSeries - NDailyPermanentSeriesFirst;
                await Context.Channel.SendMessageAsync($"💸 | Sie haben `{CurrencyPlus}`€ durch die Tagesbelohnung bekommen. Sie haben sich außerdem `{PermanentSeriesDiff}` Dailypunkte dazuverdient!");
            }
            else
            {
                await Context.Channel.SendMessageAsync($"💸 | Sie haben `{CurrencyPlus}`€ durch die Tagesbelohnung bekommen!");
            }

            if (account.NDailySeries > account.NDailyHighestSeries)
            {
                account.NDailyHighestSeries = account.NDailySeries;
            }

            UserAccounts.SaveAccounts();
        }
        [Command("data")] // DataPaare zählen
        public async Task GetData()
        {
            await Context.Channel.SendMessageAsync("Data Has " + DataStoragePairs.GetPairsCount() + " pairs.");
            DataStoragePairs.AddPairToStorage("Count" + DataStoragePairs.GetPairsCount(), "TheCount" + DataStoragePairs.GetPairsCount());
        }

        // EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE

        [Command("echo")] // Echo
        public async Task Echo([Remainder] string message)
        {
            string username = Context.User.Username;

            var embed = new EmbedBuilder();
            embed.WithTitle("Wiederholte Nachricht");
            embed.WithDescription($"Von **{username}**: \"{message}\"");
            embed.WithColor(new Color(0, 255, 0));

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }
        [Command("event")] // Claim Event
        public async Task ClaimEvent()
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            Events.EventClaimer(Context.User, Context.Message.CreatedAt.Month, Context.Message.CreatedAt.Day, Context.Channel);
        }

        // HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH



        // IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII        

        [Command("Iaccept")]
        public async Task InventoryAcceptTrade(string Value)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            var targetaccount = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (Value == "cached")
            {
                targetaccount = UserAccounts.GetOrCreateAccount(account.CacheRequestingPartnerID);
                account.CacheRequestingPartnerID = 0;
            }
            else if (Value == "uncached")
            {
                targetaccount = UserAccounts.GetOrCreateAccount(account.RequestingPartnerID);
                account.RequestingPartnerID = 0;
            }
            else
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Falsche Eingabe!");
                return;
            }

            string RequesterWants = "N";
            string RequestedGets = "N";
            if (targetaccount.TradingStatus == 1)
            {
                RequesterWants = "I";
                RequestedGets = "I";
            }
            else if (targetaccount.TradingStatus == 2)
            {
                RequesterWants = "I";
                RequestedGets = "M";
            }
            else if (targetaccount.TradingStatus == 3)
            {
                RequesterWants = "M";
                RequestedGets = "I";
            }

            if (account.CacheStatus > 1)
            {
                if (RequestedGets == "M")
                {
                    account.Currency += targetaccount.StoreCurrency;
                    targetaccount.StoreCurrency = 0;
                }
                else
                {
                    IFunctions.AddItem(targetaccount.StoreID, 1, Context.User);
                    targetaccount.StoreID = 0;
                }
            }
            else
            {
                if (RequestedGets == "M")
                {
                    double Money = Convert.ToDouble(targetaccount.OwnObjectID);
                    if (targetaccount.Currency >= Money)
                    {
                        account.Currency += Money;
                        targetaccount.Currency -= Money;
                    }
                    else
                    {
                        await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Der anfragende User hat nicht genügend Geld.");
                        return;
                    }
                }
                else
                {
                    account.StoreID = targetaccount.OwnObjectID;
                    targetaccount.ItemMinus = targetaccount.OwnObjectID;
                }
            }

            if (RequesterWants == "M")
            {
                double Money = Convert.ToDouble(targetaccount.WantedObjectID);
                if (account.Currency >= Money)
                {
                    targetaccount.Currency += Money;
                    account.Currency -= Money;
                }
                else
                {
                    await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie haben nicht genügend Geld.");
                    return;
                }
            }
            else
            {
                targetaccount.StoreID = targetaccount.WantedObjectID;
                account.ItemMinus = targetaccount.WantedObjectID;
            }

            await Context.Channel.SendMessageAsync($"🤝| Handel abgeschlossen: <@!{account.ID}> ✨ <@!{targetaccount.ID}>");
            targetaccount.TradingStatus = 0;
            targetaccount.OwnObjectID = 0;
            targetaccount.WantedPartnerID = 0;
            targetaccount.WantedObjectID = 0;
            if (Value == "cached")
            {
                account.CacheRequestingPartnerID = 0;
            }
            else if (Value == "uncached")
            {
                account.RequestingPartnerID = 0;
            }
            UserAccounts.SaveAccounts();
        }

        [Command("Ibuy")] // $Ibuy {ID} for own {Money} @User
        public async Task InventoryPurchase(int WantedObjectID, string For, string own, int OwnMoney, [Remainder] string asd = "")
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            var target = Context.Message.MentionedUsers.FirstOrDefault();
            var targetaccount = UserAccounts.GetOrCreateAccount(target.Id);

            if (account.Currency < OwnMoney)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie besitzen nicht genug Geld.");
                return;
            }
            if (targetaccount.parts.Exists(x => x.PartId == WantedObjectID) != true)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Der angefragte User besitzt dieses Item nicht.");
                return;
            }

            if (account.TradingStatus > 0)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie sind noch am Handeln!");
                return;
            }

            string ifStored = "";
            if (targetaccount.CacheStatus > 1)
            {
                if (account.StoreID != 0)
                {
                    await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie haben noch ein Item gesichert. Dieses können Sie durch den Command `$Istore` einsammeln.");
                    return;
                }
                account.Currency -= OwnMoney;
                account.StoreCurrency = OwnMoney;
                ifStored = " Ihr Geld wurde für die Zeit des Handels aus Ihrem Inventar entfernt.";
            }

            var lastRequester = UserAccounts.GetOrCreateAccount(account.ID);
            ulong newRequester = account.ID;
            if (targetaccount.CacheStatus == 1 || targetaccount.CacheStatus == 3)
            {
                lastRequester = UserAccounts.GetOrCreateAccount(targetaccount.RequestingPartnerID);
                targetaccount.RequestingPartnerID = account.ID;
            }
            else
            {
                lastRequester = UserAccounts.GetOrCreateAccount(targetaccount.CacheRequestingPartnerID);
                targetaccount.CacheRequestingPartnerID = account.ID;
            }
            if (lastRequester != null)
            {
                if (lastRequester.ID != newRequester)
                {
                    lastRequester.TradingStatus = 0;
                    lastRequester.WantedPartnerID = 0;
                    await Context.Channel.SendMessageAsync($"<@!{lastRequester.ID}> | Ihre Handelsanfrage wurde überschrieben.");
                }
            }
            account.TradingStatus = 2;
            account.WantedPartnerID = targetaccount.ID;
            account.WantedObjectID = WantedObjectID;
            account.OwnObjectID = OwnMoney;

            await Context.Channel.SendMessageAsync("📤 | Ihre Handelsanfrage wurde gestellt." + ifStored);
            if (targetaccount.NotificationStatus == 1)
            {
                await Context.Channel.SendMessageAsync($"📥 | @{target.Username}, Sie haben eine Handelsanfrage bekommen.");
            }
            UserAccounts.SaveAccounts();
        }

        [Command("Icheckcount")]
        public async Task CheckCountOfItem(int ItemID)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            int Anzahl = 0;
            while (account.parts.Exists(x => x.PartId == ItemID) == true)
            {
                IFunctions.SubtractItem(ItemID, 1, Context.User);
                Anzahl++;
            }
            IFunctions.AddItem(ItemID, Anzahl, Context.User);
            if (Anzahl == 0)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie besitzen dieses Item nicht.");
            }
            else
            {
                await Context.Channel.SendMessageAsync($"🗃 | Sie besitzen dieses Item `{Anzahl}`mal.");
            }
        }

        [Command("Ideny")]
        public async Task InventoryDeclineTrade(string Value)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            var targetaccount = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (Value == "cached")
            {
                targetaccount = UserAccounts.GetOrCreateAccount(account.CacheRequestingPartnerID);
                account.CacheRequestingPartnerID = 0;
            }
            else if (Value == "uncached")
            {
                targetaccount = UserAccounts.GetOrCreateAccount(account.RequestingPartnerID);
                account.RequestingPartnerID = 0;
            }
            else
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Falsche Eingabe!");
                return;
            }

            await Context.Channel.SendMessageAsync($"🤝| Handel abgelehnt: <@!{account.ID}> ⛔ <@!{targetaccount.ID}>");
            targetaccount.TradingStatus = 0;
            targetaccount.OwnObjectID = 0;
            targetaccount.WantedPartnerID = 0;
            targetaccount.WantedObjectID = 0;
            if (Value == "cached")
            {
                account.CacheRequestingPartnerID = 0;
            }
            else if (Value == "uncached")
            {
                account.RequestingPartnerID = 0;
            }
            UserAccounts.SaveAccounts();
        }

        [Command("helpI")]
        public async Task ShowInventoryHelp()
        {
            Help.DisplaySpecialHelp(Context.Channel, "Inventory");
        }

        [Command("Inventory")]
        public async Task ShowInventory()
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            int HighestID = Items.HighestID();
            string Emotes = "";
            for (int i = 1; i < HighestID + 1; i++)
            {
                if (account.parts.Exists(x => x.PartId == i) == true)
                {
                    string ItemName = Items.LookUpNameEmoteRarityWorthSpecial(i, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(i, 2);
                    string Rarity = Items.LookUpNameEmoteRarityWorthSpecial(i, 3);
                    Emotes += $"#{i}{Emote} | `{ItemName}` | {Rarity}\n";
                }
            }
            var embed = new EmbedBuilder();
            embed.WithTitle("Ihr Inventar");
            embed.WithColor(0, 191, 255);
            embed.WithDescription(Emotes);
            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }
        [Command("Inv")]
        public async Task ShowInventorySomeone(string arg = "")
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            string username = "";
            if (arg == "self")
            {
                account = UserAccounts.GetOrCreateAccount(Context.User.Id);
                username = Context.User.Username;
            }
            else
            {
                account = UserAccounts.GetOrCreateAccount(Context.Message.MentionedUsers.FirstOrDefault().Id);
                username = Context.Message.MentionedUsers.FirstOrDefault().Username;
            }
            int HighestID = Items.HighestID();
            string Emotes = "";
            for (int i = 1; i < HighestID + 1; i++)
            {
                if (account.parts.Exists(x => x.PartId == i) == true)
                {
                    string ItemName = Items.LookUpNameEmoteRarityWorthSpecial(i, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(i, 2);
                    string Rarity = Items.LookUpNameEmoteRarityWorthSpecial(i, 3);
                    Emotes += $"#{i}{Emote} | `{ItemName}` | {Rarity}\n";
                }
            }
            var embed = new EmbedBuilder();
            embed.WithTitle("Inventar von... " + username);
            embed.WithColor(0, 191, 255);
            embed.WithDescription(Emotes);
            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("Isell")]
        public async Task InventoryStoreSaleWithAmount(int ID, int Anzahl)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            for (int i = 0; i < Anzahl; i++)
            {
                if (account.parts.Exists(x => x.PartId == ID) == true)
                {
                    double Worth = Convert.ToDouble(Items.LookUpNameEmoteRarityWorthSpecial(ID, 4));
                    IFunctions.SubtractItem(ID, 1, Context.User);
                    double CurrencyPlus = Worth * 0.8;
                    account.Currency += CurrencyPlus;
                    await Context.Channel.SendMessageAsync($"💶 | Sie haben `{Items.LookUpNameEmoteRarityWorthSpecial(ID, 1)}` für {CurrencyPlus}€ verkauft.");
                }
                else
                {
                    if (Anzahl > 1)
                    {
                        await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie besitzen dieses Item nicht in dieser Stückzahl!");
                    }
                    else
                    {
                        await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie besitzen dieses Item nicht!");
                    }
                }
            }
        }

        [Command("Isell")]
        public async Task InventoryStoreSale(int ID)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (account.parts.Exists(x => x.PartId == ID) == true)
            {
                double Worth = Convert.ToDouble(Items.LookUpNameEmoteRarityWorthSpecial(ID, 4));
                IFunctions.SubtractItem(ID, 1, Context.User);
                double CurrencyPlus = Worth * 0.8;
                account.Currency += CurrencyPlus;
                await Context.Channel.SendMessageAsync($"💶 | Sie haben `{Items.LookUpNameEmoteRarityWorthSpecial(ID, 1)}` für {CurrencyPlus}€ verkauft.");
            }
            else
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie besitzen dieses Item nicht!");
            }
        }

        [Command("Isell")] // $Isell own {ID} for {Money} @User
        public async Task InventoryPlayerSale(string own, int OwnObjectID, string For, int WantedCurrency, [Remainder] string asd = "")
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            var target = Context.Message.MentionedUsers.FirstOrDefault();
            var targetaccount = UserAccounts.GetOrCreateAccount(target.Id);

            if (targetaccount.Currency < WantedCurrency)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Der angefragte User besitzt nicht genug Geld.");
                return;
            }
            if (account.parts.Exists(x => x.PartId == OwnObjectID) != true)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie besitzten dieses Item nicht.");
                return;
            }
            if (account.TradingStatus > 0)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie sind noch am Handeln!");
                return;
            }

            string ifStored = "";
            if (targetaccount.CacheStatus > 1)
            {
                if (account.StoreCurrency != 0)
                {
                    await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie haben noch Geld gesichert. Dieses können Sie durch den Command `$Istore` einsammeln.");
                    return;
                }
                IFunctions.SubtractItem(OwnObjectID, 1, Context.User);
                account.StoreID = OwnObjectID;
                ifStored = " Ihr Item wurde für die Zeit des Handels aus Ihrem Inventar entfernt.";
            }

            var lastRequester = UserAccounts.GetOrCreateAccount(account.ID);
            ulong newRequester = account.ID;
            if (targetaccount.CacheStatus == 1 || targetaccount.CacheStatus == 3)
            {
                lastRequester = UserAccounts.GetOrCreateAccount(targetaccount.RequestingPartnerID);
                targetaccount.RequestingPartnerID = account.ID;
            }
            else
            {
                lastRequester = UserAccounts.GetOrCreateAccount(targetaccount.CacheRequestingPartnerID);
                targetaccount.CacheRequestingPartnerID = account.ID;
            }
            if (lastRequester != null)
            {
                if (lastRequester.ID != newRequester)
                {
                    lastRequester.TradingStatus = 0;
                    lastRequester.WantedPartnerID = 0;
                    await Context.Channel.SendMessageAsync($"<@!{lastRequester.ID}> | Ihre Handelsanfrage wurde überschrieben.");
                }
            }
            account.TradingStatus = 3;
            account.WantedPartnerID = targetaccount.ID;
            account.WantedObjectID = WantedCurrency;
            account.OwnObjectID = OwnObjectID;

            await Context.Channel.SendMessageAsync("📤 | Ihre Handelsanfrage wurde gestellt." + ifStored);
            if (targetaccount.NotificationStatus == 1)
            {
                await Context.Channel.SendMessageAsync($"📥 | @{target.Username}, Sie haben eine Handelsanfrage bekommen.");
            }
            UserAccounts.SaveAccounts();
        }

        [Command("Iset strict")]
        public async Task SetStrictTrade(int Value)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            int CacheStatusFirst = account.CacheStatus;
            if (Value == 1)
            {
                account.CacheStatus = 1;
            }
            else if (Value == 2)
            {
                account.CacheStatus = 2;
            }
            else if (Value == 3)
            {
                account.CacheStatus = 3;
            }
            else
            {
                account.CacheStatus = 0;
            }
            if (account.CacheStatus != CacheStatusFirst)
            {
                await Context.Channel.SendMessageAsync("🗃 | Ihr Handelsstatus wurde verändert.");
            }
            else
            {
                await Context.Channel.SendMessageAsync("🗃 | Ihr Handelsstatus hat sich nicht verändert.");
            }
            UserAccounts.SaveAccounts();
        }

        [Command("Istored")]
        public async Task GetStoredThings()
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (account.TradingStatus > 0)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie sind noch am Handeln.");
                return;
            }

            if (account.StoreCurrency != 0)
            {
                account.Currency += account.StoreCurrency;
                account.StoreCurrency = 0;
                await Context.Channel.SendMessageAsync("📥 | Sie haben Geld eingesammelt!");
            }
            else if (account.StoreID != 0)
            {
                IFunctions.AddItem(account.StoreID, 1, Context.User);
                account.StoreID = 0;
                await Context.Channel.SendMessageAsync("📥 | Sie haben ein Item eingesammelt!");
            }
            else
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Es konnte nichts Gesichertes gefunden werden.");
            }

            if (account.StoreID != 0)
            {
                IFunctions.AddItem(account.StoreID, 1, Context.User);
                account.StoreID = 0;
                await Context.Channel.SendMessageAsync("📥 | Sie haben ein Item eingesammelt!");
            }
            UserAccounts.SaveAccounts();
        }


        [Command("Item")]
        public async Task GetItemInformation(int ItemID)
        {
            string Itemname = Items.LookUpNameEmoteRarityWorthSpecial(ItemID, 1);
            if (Itemname == "")
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Dieses Item wurde nicht gefunden.");
                return;
            }
            string Emote = Items.LookUpNameEmoteRarityWorthSpecial(ItemID, 2);
            string Rarity = Items.LookUpNameEmoteRarityWorthSpecial(ItemID, 3);
            string WorthString = Items.LookUpNameEmoteRarityWorthSpecial(ItemID, 4);
            int Worth = Convert.ToInt32(WorthString);
            int hexR = 0, hexG = 191, hexB = 255;
            string KindTitle = "";
            string KindEmote = "";
            if (Rarity == "Common")
            {
                hexR = 189;
                hexG = 189;
                hexB = 189;
            }
            else if (Rarity == "Uncommon")
            {
                hexR = 76;
                hexG = 175;
                hexB = 80;
            }
            else if (Rarity == "Rare")
            {
                hexR = 30;
                hexG = 136;
                hexB = 229;
            }
            else if (Rarity == "Epic")
            {
                hexR = 224;
                hexG = 64;
                hexB = 251;
            }
            else if (Rarity == "Legendary")
            {
                hexR = 255;
                hexG = 255;
                hexB = 0;
            }
            else if (Rarity == "Seasonal")
            {
                hexR = 0;
                hexG = 150;
                hexB = 136;
            }

            if (ItemID > 0 && ItemID < 201)
            {
                KindTitle = "Wert:";
                KindEmote = "💰";
            }
            else if (ItemID > 200 && ItemID < 301)
            {
                KindTitle = "Rüstungspunkte:";
                KindEmote = "🛡";
            }
            else if (ItemID > 300 && ItemID < 501)
            {
                KindTitle = "Schaden:";
                KindEmote = "⚔";
            }
            else if (ItemID > 500 && ItemID < 601)
            {
                KindTitle = "Konsumpunkte:";
                KindEmote = "🍗";
            }
            var embed = new EmbedBuilder();
            embed.WithTitle($"{Emote} {Itemname} | #{ItemID}");
            if (ItemID > 200)
            {
                string SpecialString = Items.LookUpNameEmoteRarityWorthSpecial(ItemID, 5);
                int Special = Convert.ToInt32(WorthString);
                embed.AddField(KindTitle, $"{KindEmote} {Special}", true);
            }
            embed.AddField("Wert:", $"{Worth}💶", true);
            embed.AddField("Seltenheit:", Rarity, true);
            embed.WithColor(hexR, hexG, hexB);
            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("Itrade")] // $Itrade {ID} for own {ID} @User
        public async Task InventoryTrade(int WantedObjectID, string For, string own, int OwnObjectID, [Remainder]  string asd = "")
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            var target = Context.Message.MentionedUsers.FirstOrDefault();
            var targetaccount = UserAccounts.GetOrCreateAccount(target.Id);

            if (account.parts.Exists(x => x.PartId == OwnObjectID) != true)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie besitzen dieses Item nicht.");
                return;
            }
            if (targetaccount.parts.Exists(x => x.PartId == WantedObjectID) != true)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Der angefragte User besitzt dieses Item nicht.");
                return;
            }

            if (account.TradingStatus > 0)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie sind noch am Handeln!");
                return;
            }

            string ifStored = "";
            if (targetaccount.CacheStatus > 1)
            {
                if (account.StoreID != 0)
                {
                    await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie haben noch ein Item gesichert. Dieses können Sie durch den Command `$Istore` einsammeln.");
                    return;
                }
                IFunctions.SubtractItem(OwnObjectID, 1, Context.User);
                account.StoreID = OwnObjectID;
                ifStored = " Ihr Item wurde für die Zeit des Handels aus Ihrem Inventar entfernt.";
            }

            int CheckIfUserHadTradingPartner = 0;
            var lastRequester = UserAccounts.GetOrCreateAccount(0);
            ulong newRequester = account.ID;
            if (targetaccount.CacheStatus == 1 || targetaccount.CacheStatus == 3)
            {
                if (targetaccount.RequestingPartnerID != 0)
                {
                    CheckIfUserHadTradingPartner = 1;
                }
                lastRequester = UserAccounts.GetOrCreateAccount(targetaccount.RequestingPartnerID);
                targetaccount.RequestingPartnerID = account.ID;
            }
            else
            {
                if (targetaccount.CacheRequestingPartnerID != 0)
                {
                    CheckIfUserHadTradingPartner = 1;
                }
                lastRequester = UserAccounts.GetOrCreateAccount(targetaccount.CacheRequestingPartnerID);
                targetaccount.CacheRequestingPartnerID = account.ID;
            }
            if (lastRequester != null)
            {
                if (CheckIfUserHadTradingPartner == 1)
                {
                    if (lastRequester.ID != newRequester)
                    {
                        lastRequester.TradingStatus = 0;
                        lastRequester.WantedPartnerID = 0;
                        lastRequester.WantedObjectID = 0;
                        lastRequester.OwnObjectID = 0;
                        await Context.Channel.SendMessageAsync($"<@!{lastRequester.ID}> | Ihre Handelsanfrage wurde überschrieben.");
                    }
                }
            }
            account.TradingStatus = 1;
            account.WantedPartnerID = targetaccount.ID;
            account.WantedObjectID = WantedObjectID;
            account.OwnObjectID = OwnObjectID;

            var dmChannel = await Context.User.GetOrCreateDMChannelAsync();
            await dmChannel.SendMessageAsync($"📤 | Ihre Handelsanfrage an `{target.Username}` wurde gestellt." + ifStored);
            if (targetaccount.NotificationStatus == 1)
            {
                dmChannel = await target.GetOrCreateDMChannelAsync();
                await dmChannel.SendMessageAsync($"📥 | Sie haben eine Handelsanfrage von `{Context.User.Username}` bekommen.");
            }
            UserAccounts.SaveAccounts();
        }

        [Command("Itrades")]
        public async Task InventoryShowTrades()
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            var embed = new EmbedBuilder();
            var embed1 = new EmbedBuilder();
            int Open = 0;
            if (account.WantedPartnerID != 0)
            {
                Open = 1;
                string Wanted = "";
                string Giving = "";
                string TradeKind = "";

                if (account.TradingStatus == 1)
                {
                    TradeKind = "Tausch";
                }
                else if (account.TradingStatus == 2)
                {
                    TradeKind = "Kauf";
                }
                else if (account.TradingStatus == 3)
                {
                    TradeKind = "Verkauf";
                }

                if (account.TradingStatus == 1 || account.TradingStatus == 2)
                {
                    string Name = Items.LookUpNameEmoteRarityWorthSpecial(account.WantedObjectID, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(account.WantedObjectID, 2);
                    Wanted = Emote + " | " + Name;
                }
                else if (account.TradingStatus == 3)
                {
                    Wanted = account.WantedObjectID + "💶";
                }

                if (account.TradingStatus == 1 || account.TradingStatus == 3)
                {
                    string Name = Items.LookUpNameEmoteRarityWorthSpecial(account.OwnObjectID, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(account.OwnObjectID, 2);
                    Giving = Emote + " | " + Name;
                }
                else if (account.TradingStatus == 2)
                {
                    Giving = account.OwnObjectID + "💶";
                }

                var target = UserAccounts.GetOrCreateAccount(account.WantedPartnerID);
                embed1.WithTitle(TradeKind);
                embed1.WithAuthor(Context.User);
                embed1.WithColor(76, 175, 80);
                embed1.AddField("Ihr Ertrag:", Wanted);
                embed1.AddField("Ihre Ausgaben:", Giving);

                await Context.Channel.SendMessageAsync("", false, embed1.Build());
            }
            if (account.CacheRequestingPartnerID != 0)
            {
                Open = 1;
                var partneraccount = UserAccounts.GetOrCreateAccount(account.CacheRequestingPartnerID);
                string Wanted = "";
                string Giving = "";
                string TradeKind = "";

                if (partneraccount.TradingStatus == 1)
                {
                    TradeKind = "Tausch";
                }
                else if (partneraccount.TradingStatus == 2)
                {
                    TradeKind = "Kauf";
                }
                else if (partneraccount.TradingStatus == 3)
                {
                    TradeKind = "Verkauf";
                }

                if (partneraccount.TradingStatus == 1 || partneraccount.TradingStatus == 2)
                {
                    string Name = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.WantedObjectID, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.WantedObjectID, 2);
                    Wanted = Emote + " | " + Name;
                }
                else if (partneraccount.TradingStatus == 3)
                {
                    Wanted = partneraccount.WantedObjectID + "💶";
                }

                if (partneraccount.TradingStatus == 1 || partneraccount.TradingStatus == 3)
                {
                    string Name = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.OwnObjectID, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.OwnObjectID, 2);
                    Giving = Emote + " | " + Name;
                }
                else if (partneraccount.TradingStatus == 2)
                {
                    Giving = partneraccount.OwnObjectID + "💶";
                }

                var target = UserAccounts.GetOrCreateAccount(partneraccount.WantedPartnerID);
                embed.WithTitle(TradeKind);
                embed.WithColor(0, 191, 255);
                embed.AddField("Antrag von:", partneraccount.Username);
                embed.AddField("Ihre Ausgaben:", Wanted);
                embed.AddField("Ihr Ertrag:", Giving);
                embed.WithFooter("- Cached");
                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
            if (account.RequestingPartnerID != 0)
            {
                Open = 1;
                var partneraccount = UserAccounts.GetOrCreateAccount(account.RequestingPartnerID);
                string Wanted = "";
                string Giving = "";
                string TradeKind = "";

                if (partneraccount.TradingStatus == 1)
                {
                    TradeKind = "Tausch";
                }
                else if (partneraccount.TradingStatus == 2)
                {
                    TradeKind = "Kauf";
                }
                else if (partneraccount.TradingStatus == 3)
                {
                    TradeKind = "Verkauf";
                }

                if (partneraccount.TradingStatus == 1 || partneraccount.TradingStatus == 2)
                {
                    string Name = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.WantedObjectID, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.WantedObjectID, 2);
                    Wanted = Emote + " | " + Name;
                }
                else if (partneraccount.TradingStatus == 3)
                {
                    Wanted = partneraccount.WantedObjectID + "💶";
                }

                if (partneraccount.TradingStatus == 1 || partneraccount.TradingStatus == 3)
                {
                    string Name = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.OwnObjectID, 1);
                    string Emote = Items.LookUpNameEmoteRarityWorthSpecial(partneraccount.OwnObjectID, 2);
                    Giving = Emote + " | " + Name;
                }
                else if (partneraccount.TradingStatus == 2)
                {
                    Giving = partneraccount.OwnObjectID + "💶";
                }

                var target = UserAccounts.GetOrCreateAccount(partneraccount.WantedPartnerID);
                embed.WithTitle(TradeKind);
                embed.WithColor(0, 191, 255);
                embed.AddField("Antrag von:", partneraccount.Username);
                embed.AddField("Ihre Ausgaben:", Wanted);
                embed.AddField("Ihr Ertrag:", Giving);
                embed.WithFooter("- Uncached");
                await Context.Channel.SendMessageAsync("", false, embed.Build());
            }
            if (Open == 0)
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ONo") + " Sie haben keine laufenden Händel!");
            }
        }

        // LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

        [Command("lvl")] // Wie viel Xp für..
        public async Task WhatXpIsnLevel(uint level)
        {
            uint xp = level * level * 50;
            await Context.Channel.SendMessageAsync($"⁉| Für Level {level} werden {xp} XP benötigt.");
        }

        // PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

        [Command("profile")] // Profile
        public async Task ShowProfile([Remainder]string arg = "")
        {
            SocketUser target = null;
            var mentionedUser = Context.Message.MentionedUsers.FirstOrDefault();
            target = mentionedUser ?? Context.User;
            var account = UserAccounts.GetOrCreateAccount(target.Id);
            var embed = new EmbedBuilder();

            embed.WithAuthor(target);

            if (account.MembershipPluses != 0 || account.Alpha != 0)
            {
                if (account.Sex != null)
                {
                    string Badges = Process.BadgeProcess(target);
                    embed.AddField($"{account.Sex} - Badges", $"{Badges}");
                }
                else if (account.Sex == null)
                {
                    string Badges = Process.BadgeProcess(target);
                    embed.AddField($"Badges", $"{Badges}");
                }
            }

            string SProgress = Core.ProfileSystem.Leveling.LevelProcess(target);
            embed.AddField("Fortschritt", $"Währung: {account.Currency}€\n" +
                $"Punkte: {account.Points}\n" +
                $"{SProgress}");

            if (account.DoJ != null || account.DoB != null)
            {
                if (account.DoJ != null && account.DoB != null)
                {
                    embed.AddField("Daten", $"Geburtsdatum: {account.DoB}\nJoindatum: {account.DoJ}");
                }
                else if (account.DoJ != null && account.DoB == null)
                {
                    embed.AddField("Daten", $"Joindatum: {account.DoJ}");
                }
                else if (account.DoJ == null && account.DoB != null)
                {
                    embed.AddField("Daten", $"Geburtsdatum: {account.DoB}");
                }
            }
            embed.AddField("Belohnung", $"Derzeitige Serie: {account.NDailySeries}\n" +
                $"Höchste Serie: {account.NDailyHighestSeries}\n" +
                $"Dailypunkte: {account.NDailyPermanentSeries}");

            embed.WithThumbnailUrl(account.PP);

            embed.WithColor(new Color(account.Hex1, account.Hex2, account.Hex3));

            embed.WithFooter("- Project Λlpha");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        // RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR        

        [Command("react")] // 
        public async Task HandleReactionMessage()
        {
            RestUserMessage msg = await Context.Channel.SendMessageAsync("Reagiere auf mich!");
            Global.MessageIdToTrack = msg.Id;
        }

        // SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

        [Command("secret")] // BesitzerCommand - Secret
        public async Task RevealSecret([Remainder] string arg = "")
        {
            if (!Process.UserIsBesitzer((SocketGuildUser)Context.User))
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ERROR_PERMISSION"));
                return;
            }
            var dmChannel = await Context.User.GetOrCreateDMChannelAsync();
            await dmChannel.SendMessageAsync(Utilities.GetAlert("SECRET"));
        }
        [Command("setalpha")] // TeamCommand - AlphaVariable setzen
        public async Task SetAlpha(int Alpha, [Remainder] string arg = "")
        {
            if (!Process.UserIsStaff((SocketGuildUser)Context.User))
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ERROR_PERMISSION"));
                return;
            }

            SocketUser target = null;
            var mentionedUser = Context.Message.MentionedUsers.FirstOrDefault();
            target = mentionedUser ?? Context.User;
            var account = UserAccounts.GetOrCreateAccount(target.Id);

            int AlphaFirst = account.TimeEvent;

            if (Alpha == 1)
            {
                account.Alpha = 1;
            }
            else if (Alpha == 2)
            {
                account.Alpha = 2;
            }
            else if (Alpha == 3)
            {
                account.Alpha = 3;
            }
            else
            {
                account.Alpha = 0;
            }
            UserAccounts.SaveAccounts();

            if (account.Alpha != AlphaFirst)
            {
                if (target == mentionedUser)
                {
                    await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Der Alphastatus wurde erfolgreich geändert.");
                }
                else if (target == Context.User)
                {
                    await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr Alphastatus wurde erfolgreich geändert.");
                }
            }
            else if (account.Alpha == AlphaFirst)
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Befehl wurde zur Kenntnis genommen, jedoch ist keine Änderung bemerkbar.");
            }
            else
            {
                if (target == mentionedUser)
                {
                    await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Der Alphastatus konnte nicht verändert werden.");
                }
                else if (target == Context.User)
                {
                    await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Alphastatus konnte nicht verändert werden.");
                }
            }
        }
        [Command("setdob")] // Profil - GB setzen
        public async Task SetDateOfBirthShort(string Short)
        {
            await Context.Channel.SendMessageAsync($"{Utilities.GetAlert("ONo")}" + " Der Syntax lautet `$setdob {TT} {MM} {JJJJ}`!");
            return;
        }
        [Command("setdob")] // Profil - GB setzen
        public async Task SetDateOfBirth(string TT, string MM, string JJJJ)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (account.Restriction == 1) return;

            if (TT.Length != 2 || MM.Length != 2 || JJJJ.Length != 4)
            {
                await Context.Channel.SendMessageAsync($"{Utilities.GetAlert("ONo")}" + " Der Syntax lautet `$setdob {TT} {MM} {JJJJ}`!");
                return;
            }
            string DoB = TT + "." + MM + "." + JJJJ;
            string DoBFirst = account.DoB;
            account.DoB = DoB;

            UserAccounts.SaveAccounts();

            if (DoB != DoBFirst)
            {
                await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr Geburtsdatum wurde erfolgreich geändert.");
            }
            else if (DoB == DoBFirst)
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Befehl wurde zur Kenntnis genommen, jedoch ist keine Änderung bemerkbar.");
            }
            else
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Geburtsdatum konnte nicht verändert werden.");
            }
        }
        [Command("setdoj")] // Profil - JoinDate setzen       
        public async Task SetDateOfJoinShort(string Short)
        {
            await Context.Channel.SendMessageAsync($"{Utilities.GetAlert("ONo")}" + " Der Syntax lautet `$setdob {TT} {MM} {JJJJ}`!");
            return;
        }
        [Command("setdoj")] // Profil - JoinDate setzen       
        public async Task SetDateOfJoin(string TT, string MM, string JJJJ, [Remainder] string arg = "")
        {
            if (!Process.UserIsStaff((SocketGuildUser)Context.User))
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ERROR_PERMISSION"));
                return;
            }

            if (TT.Length != 2 || MM.Length != 2 || JJJJ.Length != 4)
            {
                await Context.Channel.SendMessageAsync($"{Utilities.GetAlert("ONo")}" + " Der Syntax lautet `$setdob {TT} {MM} {JJJJ}`!");
                return;
            }
            SocketUser target = null;
            var mentionedUser = Context.Message.MentionedUsers.FirstOrDefault();
            target = mentionedUser ?? Context.User;
            var account = UserAccounts.GetOrCreateAccount(target.Id);

            string DoJFirst = account.DoJ;
            string DoJ = TT + "." + MM + "." + JJJJ;
            account.DoJ = DoJ;

            UserAccounts.SaveAccounts();

            if (DoJ != DoJFirst)
            {
                if (target == mentionedUser)
                {
                    await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Das Joindatum wurde erfolgreich geändert.");
                }
                else if (target == Context.User)
                {
                    await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr Joindatum wurde erfolgreich geändert.");
                }
            }
            else if (DoJ == DoJFirst)
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Befehl wurde zur Kenntnis genommen, jedoch ist keine Änderung bemerkbar.");
            }
            else
            {
                if (target == mentionedUser)
                {
                    await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Das Joindatum konnte nicht verändert werden.");
                }
                else if (target == Context.User)
                {
                    await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Joindatum konnte nicht verändert werden.");
                }
            }
        }
        [Command("sethex")] // Profil - Hex-Color-Code setzen
        public async Task SetHexColors(int Hex1, int Hex2, int Hex3)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (account.Restriction == 1) return;

            int Hex1First = account.Hex1;
            int Hex2First = account.Hex2;
            int Hex3First = account.Hex3;
            account.Hex1 = Hex1;
            account.Hex2 = Hex2;
            account.Hex3 = Hex3;

            UserAccounts.SaveAccounts();
            if (Hex1 != Hex1First || Hex2 != Hex2First || Hex3 != Hex3First)
            {
                await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr Hex-Color-Code wurde erfolgreich geändert.");
            }
            else if (Hex1 == Hex1First && Hex2 == Hex2First && Hex3 == Hex3First)
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Befehl wurde zur Kenntnis genommen, jedoch ist keine Änderung bemerkbar.");
            }
            else
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Hex-Color-Code konnte nicht verändert werden.");
            }
        }
        [Command("setmember")] // AdminCommand - MemberVariable setzen  
        [RequireUserPermission(GuildPermission.Administrator)]
        public async Task SetMembership(int Membership, [Remainder] string arg = "")
        {
            if (!Process.UserIsStaff((SocketGuildUser)Context.User))
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ERROR_PERMISSION"));
                return;
            }

            SocketUser target = null;
            var mentionedUser = Context.Message.MentionedUsers.FirstOrDefault();
            target = mentionedUser ?? Context.User;
            var account = UserAccounts.GetOrCreateAccount(target.Id);

            int MembershipFirst = account.MembershipPluses;

            if (Membership == 1)
            {
                account.MembershipPluses = 1;
            }
            else if (Membership == 2)
            {
                account.MembershipPluses = 2;
            }
            else
            {
                account.MembershipPluses = 0;
            }
            UserAccounts.SaveAccounts();

            if (account.MembershipPluses != MembershipFirst)
            {
                if (target == mentionedUser)
                {
                    await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Der Alphastatus wurde erfolgreich geändert.");
                }
                else if (target == Context.User)
                {
                    await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr Alphastatus wurde erfolgreich geändert.");
                }
            }
            else if (account.MembershipPluses == MembershipFirst)
            {
                await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Befehl wurde zur Kenntnis genommen, jedoch ist keine Änderung bemerkbar.");
            }
            else
            {
                if (target == mentionedUser)
                {
                    await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Der Alphastatus konnte nicht verändert werden.");
                }
                else if (target == Context.User)
                {
                    await Context.Channel.SendMessageAsync("<:VoteNo:539236909042630666> | Ihr Alphastatus konnte nicht verändert werden.");
                }
            }
        }
        [Command("setpp")] // Profil - Profilbild setzen
        public async Task SetProfilePicture(string pp, [Remainder] string arg = "")
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (account.Restriction == 1) return;

            string PPFirst = account.PP;


            if (pp == "pp" || pp == "Pb" || pp == "pb")
            {
                account.PP = Context.User.GetAvatarUrl();
                await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr lokales Profilbild wurde erfolgreich aktualisiert. Sie benutzen nun Ihr globales Profilbild.");
            }
            else if (pp == "Alpha" || pp == "alpha")
            {
                account.PP = "https://cdn.discordapp.com/attachments/520251669615869954/537365739351310338/530239845625495553.png";
                await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr lokales Profilbild wurde erfolgreich aktualisiert. Sie benutzen nun das offizielle Alpha-Profilbild.");
            }
            else
            {
                account.PP = pp;
                await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Ihr lokales Profilbild wurde erfolgreich aktualisiert.");
            }
            UserAccounts.SaveAccounts();
        }
        [Command("setpush")]
        public async Task SetPushNotification(int Value)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (Value == 0)
            {
                account.NotificationStatus = 0;
                await Context.Channel.SendMessageAsync("📯 | Ihre Notifications wurden ausgestellt!");
            }
            else
            {
                account.NotificationStatus = 1;
                await Context.Channel.SendMessageAsync("📯 | Ihre Notifications wurden angestellt!");
            }
            UserAccounts.SaveAccounts();
        }
        [Command("setsex")] // Profil - Geschlecht setzen
        public async Task SetSex(string Sex)
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);
            if (account.Restriction == 1) return;
            string SexFirst = account.Sex;
            if (Process.UserIsMale((SocketGuildUser)Context.User) == true)
            {
                account.Sex = "M";
                await Context.Channel.SendMessageAsync("🚹 | Ihre Geschlechtsausweisung konnte aufgrund Ihrer Rollen (Settings-Angabe) bestimmt werden.");
                UserAccounts.SaveAccounts();
                return;
            }
            else if (Process.UserIsFemale((SocketGuildUser)Context.User) == true)
            {
                account.Sex = "W";
                await Context.Channel.SendMessageAsync("🚺 | Ihre Geschlechtsausweisung konnte aufgrund Ihrer Rollen (Settings-Angabe) bestimmt werden.");
                UserAccounts.SaveAccounts();
                return;
            }

            if (Sex == "M" || Sex == "m")
            {
                Sex = "M";
            }
            else if (Sex == "W" || Sex == "w" || Sex == "F" || Sex == "f")
            {
                Sex = "W";
            }
            if (Sex == SexFirst)
            {
                if (Sex == "M")
                {
                    await Context.Channel.SendMessageAsync("🚹 | Ihre Geschlechtsausweisung ist schon auf 'M' gestellt.");
                }
                else if (Sex == "W")
                {
                    await Context.Channel.SendMessageAsync("🚺 | Ihre Geschlechtsausweisung ist schon auf 'W' gestellt.");
                }
            }
            else if (Sex != SexFirst)
            {
                if (Sex == "M")
                {
                    account.Sex = "M";
                    await Context.Channel.SendMessageAsync("🚹 | Ihre Geschlechtsausweisung wurde erfolgreich aktualisiert.");
                }
                else if (Sex == "W")
                {
                    account.Sex = "W";
                    await Context.Channel.SendMessageAsync("🚺 | Ihre Geschlechtsausweisung wurde erfolgreich aktualisiert.");
                }
            }
            else
            {
                await Context.Channel.SendMessageAsync("🚻 | Ihre Geschlechtsausweisung konnte nicht verändert werden.");
            }
            UserAccounts.SaveAccounts();
        }
        [Command("setr")] // TeamCommand - Restriction setzen      
        public async Task SetRestriction(int restriction, [Remainder] string arg = "")
        {
            if (!Process.UserIsStaff((SocketGuildUser)Context.User))
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("ERROR_PERMISSION"));
                return;
            }

            SocketUser target = Context.Message.MentionedUsers.FirstOrDefault();
            var targetaccount = UserAccounts.GetOrCreateAccount(target.Id);
            var useraccount = UserAccounts.GetOrCreateAccount(Context.User.Id);

            if (restriction == 0)
            {
                targetaccount.Restriction = 0;
                await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Die Restriction wurde erfolgreich entfernt.");
            }
            else if (restriction == 1)
            {
                targetaccount.Restriction = 1;
                await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Die Restriction wurde erfolgreich durchgesetzt.");
            }
            else if (restriction == 2)
            {
                if (!Process.UserIsBesitzer((SocketGuildUser)Context.User))
                {
                    await Context.Channel.SendMessageAsync(Utilities.GetAlert("ERROR_PERMISSION"));
                }
                else
                {
                    targetaccount.Restriction = 2;
                    await Context.Channel.SendMessageAsync("<:VoteYes:539236909109739570> | Die Restriction wurde erfolgreich durchgesetzt.");
                }
            }
            UserAccounts.SaveAccounts();
        }
        [Command("stats")] // Stats
        public async Task ShowStats([Remainder] string arg = "")
        {
            SocketUser target = null;
            var mentionedUser = Context.Message.MentionedUsers.FirstOrDefault();
            target = mentionedUser ?? Context.User;
            var account = UserAccounts.GetOrCreateAccount(target.Id);

            string SProgress = Core.ProfileSystem.Leveling.LevelProcess(target);

            var embed = new EmbedBuilder();
            embed.WithAuthor(target);
            embed.AddField("Levelfortschritt", SProgress, true);
            embed.WithColor(new Color(account.Hex1, account.Hex2, account.Hex3));
            embed.WithThumbnailUrl(account.PP);
            embed.WithFooter("- Project Λlpha");
            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        // TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

        [Command("timer")] // Timer 
        public async Task TimerPerson(double TimerMinuten, [Remainder] string TimerGrund)
        {
            Timer loopingTimer;
            TimerMinuten = TimerMinuten * 60000;
            ulong useridTimer = Context.User.Id;
            loopingTimer = new Timer()
            {
                Interval = TimerMinuten,
                Enabled = true,
                AutoReset = false
            };
            loopingTimer.Elapsed += OnTimerEnded1;
            TimerMinuten = TimerMinuten / 60000;
            async void OnTimerEnded1(object sender, ElapsedEventArgs e)
            {
                await Context.Channel.SendMessageAsync($"⌛ | <@!{useridTimer}>\nIhr Timer ist abgelaufen\nGestellt vor: `{TimerMinuten}`min\nFür: `{TimerGrund}`");
            }
            if (TimerMinuten > 0)
            {
                await Context.Channel.SendMessageAsync("⏳ | Ihr Timer wurde gestellt.");
            }
            else
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("OError"));
            }
        }
        [Command("timer")] // Timer (ohne Reason)
        public async Task TimerPerson2(double TimerMinuten, [Remainder] string arg = "")
        {
            Timer loopingTimer;
            TimerMinuten = TimerMinuten * 60000;
            ulong useridTimer = Context.User.Id;
            loopingTimer = new Timer()
            {
                Interval = TimerMinuten,
                Enabled = true,
                AutoReset = false
            };
            loopingTimer.Elapsed += OnTimerEnded1;
            TimerMinuten = TimerMinuten / 60000;
            async void OnTimerEnded1(object sender, ElapsedEventArgs e)
            {
                await Context.Channel.SendMessageAsync($"⌛ | <@!{useridTimer}>\nIhr Timer ist abgelaufen\nGestellt vor: `{TimerMinuten}`min");
            }
            if (TimerMinuten > 0)
            {
                await Context.Channel.SendMessageAsync("⏳ | Ihr Timer wurde gestellt.");
            }
            else
            {
                await Context.Channel.SendMessageAsync(Utilities.GetAlert("OError"));
            }
        }

        // UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

        [Command("update")]
        public async Task Update()
        {
            var account = UserAccounts.GetOrCreateAccount(Context.User.Id);

            string SexFirst = account.Sex;
            int AlphaFirst = account.Alpha;
            int MemberFirst = account.MembershipPluses;
            if (Process.UserIsMale((SocketGuildUser)Context.User) == true)
            {
                account.Sex = "M";
                UserAccounts.SaveAccounts();
            }
            else if (Process.UserIsFemale((SocketGuildUser)Context.User) == true)
            {
                account.Sex = "W";
                UserAccounts.SaveAccounts();
            }

            if (Process.UserIsRekrut1((SocketGuildUser)Context.User) == true) account.Alpha = 1;
            if (Process.UserIsSoldat1((SocketGuildUser)Context.User) == true) account.Alpha = 2;
            if (Process.UserIsTruppf1((SocketGuildUser)Context.User) == true || Process.UserIsKompanief1((SocketGuildUser)Context.User) == true) account.Alpha = 3;

            if (Process.UserHasMemberShipPluses((SocketGuildUser)Context.User) == true) account.MembershipPluses = 1;

            if (SexFirst != account.Sex || AlphaFirst != account.Alpha || MemberFirst != account.MembershipPluses)
            {
                await Context.Channel.SendMessageAsync("🔂 | Ihr Account konnte erfolgreich aktualisiert werden.");
            }
            else
            {
                await Context.Channel.SendMessageAsync("🔁 | Es wurden keine Updates gefunden.");
            }
            UserAccounts.SaveAccounts();
            return;
        }

        // XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

        [Command("xp")] // Welches Level bei..
        public async Task WhatLevelIsnXP(uint xp)
        {
            uint level = (uint)Math.Sqrt(xp / 50);
            await Context.Channel.SendMessageAsync($"⁉| Das Level für {xp} XP beträgt {level}.");
        }

        // ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ

        [Command("zufall")] // RandomPicker
        public async Task PickOne([Remainder] string message)
        {
            string username = Context.User.Username;
            string[] options = message.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

            Random r = new Random();
            string seletion = options[r.Next(0, options.Length)];

            var embed = new EmbedBuilder();
            embed.WithTitle($"Wahl von {username}");
            embed.WithDescription(seletion);
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/471249140215447562/520712420126228480/1.221.jpg");

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        // --------------------------------------------------------------------------------------------------------------------------------

        /*
        [Command("update")]
        public async Task GivingRoles()
        {
            var account = UserAccounts.GetAccount(Context.User);
            var user = (SocketGuildUser)Context.User;
            if (account.RTrash == 1)
            {
                var role = Context.Guild.Roles.FirstOrDefault(x => x.Name.ToString() == "Besitzer");
            }
            else
            {
                var role = Context.Guild.Roles.FirstOrDefault(x => x.Name.ToString() == "Besitzer");

            }
            // Delete Roles
            await (user as IGuildUser).RemoveRolesAsync(rrole1, rrole2);

            // Add Role
            await (user as IGuildUser).AddRoleAsync(role);
        } /
        [Command("CPalpha")]
        [RequireUserPermission(GuildPermission.Administrator)]
        public async Task AlphaChannel()
        {
            Core.CopyPastes.AlphaChannel(Context.Channel);
        }
        [Command("CPeingang")]
        [RequireUserPermission(GuildPermission.Administrator)]
        public async Task Eingangshalle()
        {
            Core.CopyPastes.Eingangshalle(Context.Channel);
        }
        [Command("CPrating")]
        [RequireUserPermission(GuildPermission.Administrator)]
        public async Task RatingChannel()
        {
            Core.CopyPastes.RatingChannel(Context.Channel);
        }
        [Command("CPsettings")]
        [RequireUserPermission(GuildPermission.Administrator)]
        public async Task Settingsexe()
        {
            Core.CopyPastes.Settingschannel(Context.Channel);
        }*/
    }
}
