﻿using Discord;
using Discord.WebSocket;

namespace AlphaBot.Modules.MiscSupply.BotAdminSupply
{
    internal static class Pasting
    {
        internal static async void AlphaChannel(ISocketMessageChannel Channel) // Alpha
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("Project Alpha");
            embed.WithDescription("- Zurzeit nicht vorhanden\n\nFalls Sie jedoch Interesse an der Teilnahme haben, dann reagieren Sie bitte auf das :mortar_board:-Emote. Somit sehen wir, wie viel Interesse an *'Project Alpha'*, also an gemeinsamen Events wie Voicechatpartys, Serverraids, Gamingabenden und ähnlichem, vorliegt.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://raw.githubusercontent.com/AsderPNH/AlphaBot/Icons/Icon_Alpha01.png");
            embed.WithFooter("- AsderGaming");
            await Channel.SendMessageAsync("", false, embed.Build());
        }

        internal static async void RatingChannel(ISocketMessageChannel Channel) // Rating
        {
            await Channel.SendMessageAsync("📀📀📀📀💿\nEin Rating hat wie diese Nachricht hier auszusehen. Bei diesem Beispiel handelt es sich um 4/5 Punkte(n). Dinge, die Sie gut oder schlecht finden, können Sie dann in diesen Text schreiben. Bitte beachten Sie aber, dass dieser Channel nicht als Plattform für Verbesserungsvorschläge genutzt werden soll. Dafür haben wir andere Funktionen. Mehr Infos können Sie sich vom Serverteam einholen.");
        }

        internal static async void Eingangshalle(ISocketMessageChannel Channel) // Eingangshalle
        {
            var embed1 = new EmbedBuilder();
            embed1.WithDescription("Project Alpha");
            embed1.WithImageUrl("https://raw.githubusercontent.com/AsderPNH/AlphaBot/Pictures/AP_ProjectAlpha.png");
            embed1.WithColor(new Color(0, 191, 255));
            await Channel.SendMessageAsync("", false, embed1.Build());

            // Welcome & Serverinhalte & Regeln 
            await Channel.SendMessageAsync("**Herzlich willkommen**\nHier haben Sie, wie auf gewöhnlichen Servern, die Möglichkeit mit anderen Servermitgliedern zu interagieren und Freundschaften zu schließen **__oder__** *'Project Alpha'*  beizutreten, um kleineren Aktionen und Events beizuwohnen, auf DC Liebe zu verbreiten, Punkte zu sammeln oder an VC-Partys teilzunehmen. Falls Sie mehr erfahren wollen, lesen Sie unten mehr.\n\n:sparkles: __**Serverinhalte und -funktionen**__\n<:Alpha:530239845625495553> : Project Alpha\n:date: : Serverevents\n:gear: : Individuelle Gestaltungsmöglichkeiten\n:1234: : Punktesystem\n:up: : Levelingsystem\n:fleur_de_lis: : Badgesystem\n:robot: : Eigener Serverbot\n:video_game: : Viele andere Bots\n\n:1234: **__Grundregeln:__**\n**Verbotenes:**\n**1.** Beleidigen anderer User und Lästern.\n**2.** Spammen und übermäßiges Benutzen von CapsLock.\n**3.** Das Provozieren von Staff-Membern.\n**4.** Teilen von verdächtigen Links und Posten von unangemessenen Bildern.\n**5.** Das Ausnutzen von Serverrängen.\n**6.** Das wiederholte Betteln nach Serverrängen.\n**7.** Das Werben, ohne Zustimmung eines Mitglieds des Serverteams.\n\n<:Alpha:530239845625495553> __**Project Alpha**__");

            // Alpha
            await Channel.SendMessageAsync("Bei *Project Alpha*  werden, als fähig eingeschätzte User rekrutiert, ausgebildet und dann in einer Art militärischen Gruppe (es gibt Züge, Kompanien und Bataillons) eingegliedert, in der sie die Möglichkeit haben aufzusteigen (zum Zugführer zum Beispiel), wenn sie an den Aktionen (dazu gehören Serverraids und ähnliche) aktiv teilnehmen. Das Ziel von Projekt Alpha ist es, DC durch gute Aktionen zu einem besseren Ort zu machen, zu einem Ort des Miteinanders und vor allem Spaß zu haben, eine Gemeinschaft aufzubauen, eine Gemeinschaft mit Ordnung. :)\n\n:pencil: **__Zutritt__**");

            // Zutritt & Schneller Zutritt & Settings
            await Channel.SendMessageAsync("Wenn Sie alles durchgelesen und akzeptiert haben, können Sie mit einem :pencil:-Emote reagieren, um Zugang zu den Standardchannels zu bekommen.\n\n:fast_forward: **__Schneller Zutritt__**\nSie haben auch die Möglichkeit auf das :fast_forward:-Emote zu reagieren, um erst mal fast alle Channels des Servers freizuschalten. Zu bemerken ist, dass Sie nur eine der Optionen hier gleichzeitig gewählt haben können.\n\n:gear: **__Settings__**\nSie können auch einfach auf das :gear:-Emote reagieren um Ihre Einstellungen und Channelauswahl zu ändern. Dem normalen User werden nur ein paar Channels angezeigt, um Ihn nicht direkt zu überfordern oder nerven.");

            embed1.WithDescription("- AsderGaming");
            embed1.WithImageUrl("https://raw.githubusercontent.com/AsderPNH/AlphaBot/Pictures/AP_ProjectAlpha-Blank.png");
            embed1.WithColor(new Color(0, 191, 255));
            await Channel.SendMessageAsync("", false, embed1.Build());
        }

        internal static async void Settingschannel(ISocketMessageChannel Channel) // Settings
        {
            var embed = new EmbedBuilder();

            await Channel.SendMessageAsync(":gear:️ **__settings.exe__**\nHier haben Sie die Möglichkeit, Ihre Standardchannels und andere Funktionen an- und auszuschalten, um den Server nach Ihren Präferenzen zu gestalten. Durch das Reagieren auf die jeweilige Nachricht schalten Sie den Channel oder die Funktion an. Wenn Sie eine loszuwerdende Subscription haben, jedoch keine Reaktion auf das ungewollte Abo, müssen Sie dieses erst an- und anschließend wieder ausschalten.");

            // Sets
            embed.WithTitle("Sets");
            embed.WithDescription("Für User, die keine Lust haben, sich lange mit den Settings auseinanderzusetzen, haben wir 3 Sets beziehungsweise Rollenansammlungen bereitgestellt.");
            embed.WithColor(new Color(255, 0, 0));
            embed.WithThumbnailUrl("https://raw.githubusercontent.com/AsderPNH/AlphaBot/Picture/Icon_PaperClips.png");
            embed.WithFooter("SPACE");
            await Channel.SendMessageAsync("", false, embed.Build());
            //

            embed.WithTitle("Ergänzungsset");
            embed.WithDescription("Das Ergänzungsset ergänzt den Userrang um die restlichen Chats des externen Chatbereichs und um die Voicechats.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://raw.githubusercontent.com/AsderPNH/AlphaBot/Icons/Icon_PlusSign.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Communityset");
            embed.WithDescription("Empfohlen:\nDas Communityset ergänzt den Userrang um die Eigenschaften des Ergänzungssets und zusätzlich um, unter anderem, den Verbesserungsvorschlag- und den Geschichten-Channel. ");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861212173303821/535226972926902280.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Communityset+");
            embed.WithDescription("Dieses Set hier enthält zusätzlich noch die Channels der Intern-Rolle und somit alle angebotenen Features bis auf den NSFW-Channel.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861238337634324/535238638477508637.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            // Profilesettings
            embed.WithTitle("Profileinstellungen");
            embed.WithDescription("Hier haben Sie noch die Möglichkeit, Ihr Profil beziehungsweise Ihre Rollenidentifizierung zu erweitern.");
            embed.WithColor(new Color(255, 0, 0));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535888726455353346/card-file-box_1f5c3.png");
            embed.WithFooter("SPACE");
            await Channel.SendMessageAsync("", false, embed.Build());
            //

            embed.WithTitle("Männlich/Weiblich?");
            embed.WithDescription("Durch das Reagieren auf eines dieser Symbole (Frau oder Mann) bekommen Sie die dazugehörige Rolle. Die Angabe ist nicht erforderlich, eine Falschangabe kann jedoch zu einer Strafe führen.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861308269264917/restroom_1f6bb.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Alpha");
            embed.WithDescription("Das Reagieren gibt Ihnen Zugang zur 'Project Alpha'-Übersicht.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535897106058051584/530239845625495553.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            // Channels  
            embed.WithTitle("Channels");
            embed.WithDescription("Hier haben Sie letzten Endes die Chance, alle ihre (Wahl-)Channels beziehungsweise Channelgruppierungen zu verwalten.");
            embed.WithColor(new Color(255, 0, 0));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535888726455353346/card-file-box_1f5c3.png");
            embed.WithFooter("SPACE");
            await Channel.SendMessageAsync("", false, embed.Build());
            //            

            embed.WithTitle("Kommunikation");
            embed.WithDescription("Diese Subscription schaltet die normalen Voicechats frei, in denen mit den anderen Usern geredet werden kann, und außerdem den chat_voice, in dem stumme User die Möglichkeit haben mitzureden, oder allgemein Posts und Kontext zum Gespräch gesendet werden können.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861314762047518/studio-microphone_1f399.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Changelog");
            embed.WithDescription("Durch das Abonnieren des Changelogs bekommen Sie größere Änder- und Neuerungen mit.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535859249138368532/gear_2699.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Bots");
            embed.WithDescription("Im Botchannel können alle, für den normalen User benutzbare, Bots gesteuert beziehungsweise genutzt werden.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861301776220170/22.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Gaming");
            embed.WithDescription("Das Gamingset enthält einen Gamingchat, in dem Beiträge zum Thema Gaming gepostet werden dürfen, und die Game 'n Talk Voicechats. (Die Anzahl wird je nach Bedarf erhöht und erniedrigt). Zusätzlich sehen Sie dann noch den #chat_voice, in dem stumme User die Möglichkeit haben mitzureden, oder allgemein Posts und Kontext zum Gespräch gesendet werden können.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861305668534293/gear_26929.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Geschichten & Zitate & Witze");
            embed.WithDescription("In diesem Channel können im Titel enthaltene Inhalte gepostet und beredet werden. Die besten Posts werden nach unbestimmter Zeit herausgesucht und in den '#beste-beitraege'-Channel gestellt, welcher in diesem Abo ebenfalls enthalten ist.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/540509822596939778/open-book_1f4d6.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Rating & Vorschläge");
            embed.WithDescription("Im Rating-Channel können Sie den Server in Kommentar- und Punkteform bewerten und die Rezensionen anderer User einsehen. Ein bestimmtes Layout der Nachricht ist Pflicht und jeder User darf dort nur eine Nachricht besitzen. Außerdem bekommen Sie durch diese Subscription Zugang zu den Verbesserungsvorschlägen und Abstimmungen.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535865353797107733/white-medium-star_2b50.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Trash");
            embed.WithDescription("Der #chat_trash wird für Posts benutzt, die im Themenbereich der anderen Chats und im Hauptchat keinen Platz finden oder aus eigener Sicht unnötig für die Aufmerksamkeit der anderen User sind.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861303944937493/gear_2699.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("Intern.spy");
            embed.WithDescription("Sie wollen einen Blick hinter die Kulissen werfen? Durch das Reagieren bekommen Sie einige, sonst versteckte Channels. Dazu gehören der Populationlog, der Actionlog und der interne Vorschläge-Channel.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861302397239307/eye_1f441.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());

            embed.WithTitle("NSFW");
            embed.WithDescription("Der NotSafeForWork-Channel ist für nicht jugendfreies Material gedacht. Wer dort Illegales postet wird natürlich trotzdem sofortig gebannt. Durch das Subscriben beziehungsweise Reacten auf diese Nachricht, bestätigen Sie zu unserer Sicherheit, dass Sie mindestens 18 Jahre alt sind und genanntes Material sehen wollen.");
            embed.WithColor(new Color(0, 191, 255));
            embed.WithThumbnailUrl("https://cdn.discordapp.com/attachments/520251669615869954/535861306876624920/no-one-under-eighteen-symbol_1f51e.png");
            embed.WithFooter("Reagieren Sie, um zu abonnieren.");
            await Channel.SendMessageAsync("", false, embed.Build());
        }
    }
}
