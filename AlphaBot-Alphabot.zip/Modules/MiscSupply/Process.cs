﻿using System;
using System.Linq;

using Discord.WebSocket;

using AlphaBot.DataManagement.UserAccountsFolder;

namespace AlphaBot.Modules.MiscSupply
{
    internal static class Process
    {
        internal static string BadgeProcess(SocketUser user)
        {
            var account = UserAccounts.GetOrCreateAccount(user.Id);

            string SProgress = "";
            string Membership = "";
            string Alpha = "";
            string Alpha2 = "";

            if (account.MembershipPluses == 1)
            {
                Membership = "<:SaluteTwo:539558506743857153>";
            }
            if (account.Alpha > 0)
            {
                Alpha = "<:Alpha:530239845625495553>";
            }
            if (account.Alpha == 2)
            {
                Alpha2 = "<:SaluteLeft:531539521611759666>";
            }
            else if (account.Alpha == 3)
            {
                Alpha2 = "<:SaluteLeft:531539521611759666>";
            }

            if (account.MembershipPluses > 0 || account.Alpha > 0)
            {
                if (account.Alpha > 1)
                {
                    SProgress = Membership + Alpha + " | " + Alpha2;
                }
                else if (account.Alpha < 2)
                {
                    SProgress = Membership + Alpha;
                }
            }
            string Event = Events.BadgeProcess(account.TimeEvent);
            SProgress += "\n" + Event;
            return SProgress;
        }

        

        internal static bool UserIsBesitzer(SocketGuildUser user)
        {
            string targetRoleName = "Besitzer";            
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }
        internal static bool UserIsStaff(SocketGuildUser user)
        {
            string targetRoleName = "Besitzer";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();

            targetRoleName = "Home Guard";
            result = from r in user.Guild.Roles
                     where r.Name == targetRoleName
                     select r.Id;
            ulong roleID2 = result.FirstOrDefault();

            if (roleID == 0 && roleID2 == 0) return false;

            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }
        internal static bool UserIsMale(SocketGuildUser user)
        {
            string targetRoleName = "M";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }
        internal static bool UserIsFemale(SocketGuildUser user)
        {
            string targetRoleName = "W";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }



        internal static bool UserHasMemberShipPluses(SocketGuildUser user)
        {
            string targetRoleName = "Home Guard";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }



        internal static bool UserIsRekrut1(SocketGuildUser user)
        {
            string targetRoleName = "I | Rekrut";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }
        internal static bool UserIsSoldat1(SocketGuildUser user)
        {
            string targetRoleName = "I | Soldat";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }
        internal static bool UserIsTruppf1(SocketGuildUser user)
        {
            string targetRoleName = "I | Truppführer";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }
        internal static bool UserIsKompanief1(SocketGuildUser user)
        {
            string targetRoleName = "I | Kompanieführer";
            var result = from r in user.Guild.Roles
                         where r.Name == targetRoleName
                         select r.Id;
            ulong roleID = result.FirstOrDefault();
            if (roleID == 0) return false;
            var targetRole = user.Guild.GetRole(roleID);
            return user.Roles.Contains(targetRole);
        }
    }
}
