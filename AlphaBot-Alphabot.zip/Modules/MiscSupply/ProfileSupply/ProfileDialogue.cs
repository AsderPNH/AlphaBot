﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

using Discord;
using Discord.Commands;

using AlphaBot.DataManagement.UserAccountsFolder;
using AlphaBot.Formatting;
using AlphaBot.DataManagement.ServerAccountsFolder;

namespace AlphaBot.Modules.MiscSupply.ProfileSupply
{
    class ProfileDialogue
    {
        internal static Task ResetProgress(SocketCommandContext context)
        {
            UserAccounts.GetUserAccount(context.User.Id).DialogueProgress = 0;
            return Task.CompletedTask;
        }

        internal static Task Dialogue(SocketCommandContext context)
        {
            var userAccount = UserAccounts.GetUserAccount(context.User.Id);
            var serverAccount = ServerAccounts.GetOrCreateServerAccount(context.Guild.Id);
            var embed = new EmbedBuilder();

            if (userAccount.DialogueProgress == 0)
            {
                // extra text, if account is new
                string description = Formatting.LanguagePacks.GetFormattedSentence(context, "p-dialogue-0-embed-description2_&COMMAND", $"{serverAccount.Prefix}{Utilities.GetAlert("COMMAND_help")}");
                if (userAccount.CommandsUsed < Config.bot.userAccount_commandsUsed_lowBorder)
                {
                    description = Formatting.LanguagePacks.GetSentence(context, "p-dialogue-0-embed-description1") + description;
                }
                embed.WithTitle($"{Utilities.GetAlert("EMOTE_saluteRightRed")} | {Formatting.LanguagePacks.GetSentence(context, "p-dialogue-0-embed-title")}");
                embed.WithDescription(description);
                embed.WithColor(new Color(userAccount.Hex1, userAccount.Hex2, userAccount.Hex3));
                context.Channel.SendMessageAsync(embed: embed.Build());

                userAccount.DialogueProgress = 1; // marking progress
            }
            else if (userAccount.DialogueProgress == 1)
            {
                embed.WithTitle($"{Utilities.GetAlert("EMOTE_saluteRightRed")} | {Formatting.LanguagePacks.GetSentence(context, "p-dialogue-1-embed-title")}");
                embed.WithDescription(Formatting.LanguagePacks.GetFormattedSentence(context, "p-dialogue-1-embed-description_&COMMAND_&COMMAND", Utilities.GetAlert("COMMAND_help-specificCategory"), Utilities.GetAlert("COMMAND_help-specificCommand")));
                embed.WithColor(new Color(userAccount.Hex1, userAccount.Hex2, userAccount.Hex3));
                context.Channel.SendMessageAsync(embed: embed.Build());

                userAccount.DialogueProgress = 2; // marking progress
            }
            else if (userAccount.DialogueProgress == 2)
            {
                //// 

                userAccount.DialogueProgress = 3; // marking progress
            }
            UserAccounts.SaveAccounts();
            return Task.CompletedTask;
        }
    }
}
