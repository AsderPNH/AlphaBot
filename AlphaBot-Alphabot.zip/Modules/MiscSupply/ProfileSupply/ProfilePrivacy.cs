﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

using Discord;
using Discord.Commands;

using AlphaBot.DataManagement.ServerAccountsFolder;
using AlphaBot.DataManagement.UserAccountsFolder;
using AlphaBot.Formatting;


namespace AlphaBot.Modules.MiscSupply.ProfileSupply
{
    class ProfilePrivacy
    {
        internal static Task SignUp(SocketCommandContext context)
        {
            var userAccount = UserAccounts.GetUserAccount(context.User.Id);
            if (userAccount.DialogueProgress == 0)
            {
                ProfileDialogue.Dialogue(context);
            }
            return Task.CompletedTask;
        }

        internal static Task SendAccountFindingFailureNotification(SocketCommandContext context)
        {
            var embed = new EmbedBuilder();
            embed.WithTitle($"❗ | {Formatting.LanguagePacks.GetSentence(context, "p-SendAccountFindingFailureNotification-embed-title")}");
            embed.WithDescription(Formatting.LanguagePacks.GetFormattedSentence(context, "p-SendAccountFindingFailureNotification-embed-description_&COMMAND", Utilities.GetAlert("COMMAND_signUp")));
            embed.WithColor(new Color(0, 191, 255));
            context.Channel.SendMessageAsync(embed: embed.Build());
            return Task.CompletedTask;
        }

        internal static Task SendAccountNotCreatedYetNotification(SocketCommandContext context)
        {
            var embed = new EmbedBuilder();
            embed.WithTitle($"❗ | {Formatting.LanguagePacks.GetSentence(context, "p-SendAccountNotCreatedYetNotification-embed-title")}");
            embed.WithDescription(Formatting.LanguagePacks.GetFormattedSentence(context, "p-SendAccountNotCreatedYetNotification-embed-description_&COMMAND", Utilities.GetAlert("COMMAND_signUp"), Utilities.GetAlert("COMMAND_miscellaneous-?privacy")));
            embed.WithColor(new Color(0, 191, 255));
            context.Channel.SendMessageAsync(embed: embed.Build());
            return Task.CompletedTask;
        }

        internal static Task SendAccountCreationSuccessNotification(SocketCommandContext context) 
        {
            var embed = new EmbedBuilder();
            embed.WithTitle($"{Formatting.Utilities.GetAlert("EMOTE_true")} | {Formatting.LanguagePacks.GetSentence(context, "p-SendAccountCreationSuccessNotification-embed-title")}");
            embed.WithDescription(Formatting.LanguagePacks.GetFormattedSentence(context, "p-SendAccountCreationSuccessNotification-embed-description_&COMMAND", Utilities.GetAlert("COMMAND_miscellaneous-?privacy")));
            embed.WithColor(new Color(21, 212, 21));
            context.Channel.SendMessageAsync(embed: embed.Build());
            return Task.CompletedTask;
        }
    }
}
