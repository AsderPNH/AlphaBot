﻿using System.Threading.Tasks;
using Discord.Commands;
using AlphaBot.Formatting;

namespace AlphaBot.Modules.MiscSupply.ProfileSupply
{
    internal static class ProfileLanguage
    {
        internal static Task SetLanguage(string language, SocketCommandContext context)
        {            
            var account = DataManagement.UserAccountsFolder.UserAccounts.GetUserAccount(context.User);
            var server = DataManagement.ServerAccountsFolder.ServerAccounts.GetServerAccount(context.Guild);

            if (language.Contains('!')) // if illegal language (private folders can't be accessed)
            {
                context.Channel.SendMessageAsync(LanguagePacks.GetSentence(account.Language, server.ServerLanguage, "ERROR01")); // failure feedback
            }
            else if (LanguagePacks.LanguageExists(language) == true) // if language was found
            {
                account.Language = language;
                context.Channel.SendMessageAsync($"{Utilities.GetAlert("EMOTE_success")} | {LanguagePacks.GetFormattedSentence(account.Language, server.ServerLanguage, "p-SetLanguage-Success_&LANGUAGE", $"**{language}**")}"); // success feedback
            }
            else // if language could not be found
            {
                context.Channel.SendMessageAsync(LanguagePacks.GetSentence(account.Language, server.ServerLanguage, "ERROR01")); // failure feedback
            }

            return Task.CompletedTask;
        }
    }
}
