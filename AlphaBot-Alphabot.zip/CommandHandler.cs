﻿using System;
using System.Reflection;
using System.Threading.Tasks;

using Discord;
using Discord.Commands;
using Discord.WebSocket;

using AlphaBot.Modules.MiscSupply.ServerAdminSupply;
using AlphaBot.DataManagement.ServerAccountsFolder;
using AlphaBot.DataManagement.UserAccountsFolder;
using AlphaBot.Modules.MiscSupply.ProfileSupply;
using AlphaBot.Formatting;
using AlphaBot.ZSystem;
using System.Net.Sockets;

namespace AlphaBot
{
    class CommandHandler
    {
        DiscordSocketClient _client;
        CommandService _service;

        public async Task InitializeAsync(DiscordSocketClient client)
        {
            _client = client;
            _service = new CommandService();
            await _service.AddModulesAsync(Assembly.GetEntryAssembly(), null); //// null eingefügt
            _client.MessageReceived += HandleCommandAsync;
        }

        private async Task HandleCommandAsync(SocketMessage s)
        {
            // ---------------- validating and converting message
            SocketUserMessage msg = s as SocketUserMessage;
            if (msg == null) return;

            // context creation
            var context = new SocketCommandContext(_client, msg);

            // ---------------- return if dm
            if (context.Channel is SocketDMChannel) return;

            // user account
            UserAccount userAccount;

            // check if user account even exists
            UserAccounts.GetUserAccount(context, out bool accountExists, false); 

            // leveling
            if (accountExists && !context.User.IsBot)
            {
                Core.ProfileSystem.Leveling.UserSentMessage((SocketGuildUser)context.User, (SocketMessage)context.Message);
            }

            // ---------------- writing in channel is aloud or user is admin
            if ((!ServerSettings.IsBotchannel(context) && !Core.LocalPermissionFolder.LocalPermission.HasLocalPermission((SocketGuildUser)context.User))) return;  // channel is no bot-channel & user is no admin

            // server account
            ServerAccount serverAccount = ServerAccounts.GetOrCreateServerAccount(context.Guild.Id);

            // user is right now signing up? -> account creation + continue
            if (!accountExists && msg.ToString() == $"{serverAccount.Prefix}{Utilities.GetAlert("COMMAND_signUp")}")      
            {
                userAccount = UserAccounts.GetOrCreateUserAccount(context.User);
                UserAccounts.SaveAccounts();
                await ProfilePrivacy.SendAccountCreationSuccessNotification(context);
            }
            // not signed up yet -> notification + return
            else if (!accountExists)                                                                    
            {
                await ProfilePrivacy.SendAccountNotCreatedYetNotification(context);
                return;
            }
            // already signed up + continue
            else
            {
                userAccount = UserAccounts.GetUserAccount(context, out bool varNotNeeded, false);
            }


            /* Server name update
            serverAccount.Servername = context.Guild.Name;*/

            /* Restriction
            if (userAccount.Restriction == 2) return;
                        
            // Username
            userAccount.Username = context.User.Username;

            // TradeAcception
            if (userAccount.CurrencyMinus != 0)
            {
                userAccount.Currency -= userAccount.CurrencyMinus;
                userAccount.CurrencyMinus = 0;
            }
            if (userAccount.ItemMinus != 0)
            {
                if (Core.InventorySystem.IFunctions.SubtractItem(userAccount.ItemMinus, 1, context.User) != true)
                {
                    double CurrencyMinus = Convert.ToDouble(Core.InventorySystem.Items.LookUpNameEmoteRarityWorthSpecial(userAccount.ItemMinus, 4));
                    userAccount.Currency -= CurrencyMinus;
                    await context.Channel.SendMessageAsync($"🥊| <@!{context.User.Id}> | {CurrencyMinus}€ Strafe für das nicht Aufbringen eines Handelsgegestandes.");
                }
                userAccount.ItemMinus = 0;
            }
            if (userAccount.TradingStatus == 0)
            {
                if (userAccount.StoreCurrency != 0)
                {
                    userAccount.Currency += userAccount.StoreCurrency;
                    userAccount.StoreCurrency = 0;
                }
                if (userAccount.StoreID != 0)
                {
                    Core.InventorySystem.IFunctions.AddItem(userAccount.StoreID, 1, context.User);
                    userAccount.StoreID = 0;
                }
            }*/

            // bot account
            var botAccount = UserAccounts.GetUserAccount(Config.bot.bot_ID);

            // if message is command
            int argPos = 0;
            if (   context.Channel is SocketDMChannel                     // dm
                || userAccount.AutoPrefix == true                         // autoPrefix
                || msg.HasMentionPrefix(_client.CurrentUser, ref argPos)  // mentioned
                || msg.HasStringPrefix(serverAccount.Prefix, ref argPos)) // prefix
            {
                userAccount.CommandsUsed++; // individual command usage statistic
                botAccount.CommandsUsed++; // global command usage statistics

                var result = await _service.ExecuteAsync(context, argPos, null); // command execution

                // command: error
                if (!result.IsSuccess && result.Error != CommandError.UnknownCommand) 
                {
                    await VirtualConsole.SendCasualLog(result.ErrorReason);
                }
                // command: unknown command
                else if (!result.IsSuccess && result.Error == CommandError.UnknownCommand) 
                {
                    if (userAccount.AutoPrefix == true) userAccount.AutoPrefix_UnknownCommandsCounter++; // increasing unknown (wrong) command usage while autoPrefix is activated

                    if (userAccount.AutoPrefix_UnknownCommandsCounter >= Config.bot.userAccount_unknownCommandsWhileAutoPrefix_limit) // deactivating autoPrefix if limit of unknown (wrong) commands is reached
                    {
                        userAccount.AutoPrefix = false;
                    }
                    
                    var embed = new EmbedBuilder();
                    embed.WithColor(new Color(255, 255, 0));
                    embed.WithThumbnailUrl("");
                    embed.WithTitle("");
                    embed.WithDescription("");

                    if (userAccount.PreferDM == true)
                    {
                        SocketDMChannel channel = await context.User.GetOrCreateDMChannelAsync() as SocketDMChannel;
                        await channel.SendMessageAsync(embed: embed.Build());
                    }
                    else await context.Channel.SendMessageAsync(embed: embed.Build());
                }
                // command: success
                else
                {
                    userAccount.AutoPrefix_UnknownCommandsCounter = 0; // resetting unknown (wrong) command usage counter if/when an actual command is used
                }
            }
        }
    }
}
