﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlphaBot.ZTools
{
    class GeneralTools
    {
        internal static bool StringIsAnyOfStringArray(string targetString, string stringArray, string stringSeperator = "|")
        {
            string[] trueStringArray = stringArray.Split(stringSeperator);
            if (trueStringArray.Contains(targetString)) return true;
            else return false;
        }
        internal static bool StringIsAnyOfStringArray(string targetString, string[] stringArray)
        {
            if (stringArray.Contains(targetString)) return true;
            else return false;
        }
    }
}
