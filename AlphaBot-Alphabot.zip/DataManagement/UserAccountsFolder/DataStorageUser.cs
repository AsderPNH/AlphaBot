﻿using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace AlphaBot.DataManagement.UserAccountsFolder
{
    public static class DataStorageUser
    {
        internal static byte UserAccountFileAvailable { get; set; } // 0=unavailable 1=available 2=internalAvailable

        // Save all userAccounts
        public static void SaveUserAccounts(IEnumerable<UserAccount> userAccounts, string filePath)
        {
            if (UserAccountFileAvailable == 0 || UserAccountFileAvailable == 0) //
            { //
                ZSystem.ErrorHandler.CatchError("ERROR1"); //
                return; //
            } //


            string json = JsonConvert.SerializeObject(userAccounts, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        // Get all userAccounts
        public static IEnumerable<UserAccount> LoadUserAccounts(string filePath)
        {            
            if (!File.Exists(filePath)) return null;
            string json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<List<UserAccount>>(json);
        }

        public static bool SaveExists(string filePath)
        {
            return File.Exists(filePath);
        }
    }
}
