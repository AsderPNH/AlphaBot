﻿using System.Linq;
using System.Collections.Generic;

using Discord.WebSocket;
using Discord.Commands;

using static AlphaBot.DataManagement.UserAccountsFolder.UserAccount;
using AlphaBot.Modules.MiscSupply.ProfileSupply;

namespace AlphaBot.DataManagement.UserAccountsFolder
{
    public static class UserAccounts
    {
        private static List<UserAccount> userAccounts;
        private static string userAccountsFile = "Resources/userAccounts.json";

        static UserAccounts()
        {
            if (DataStorageUser.SaveExists(userAccountsFile))
            {
                if (DataStorageUser.UserAccountFileAvailable == 0) 
                { 
                    ZSystem.ErrorHandler.CatchError("ERROR1"); // no file access
                    return; 
                } 
                userAccounts = DataStorageUser.LoadUserAccounts(userAccountsFile).ToList();
            }
            else
            {
                userAccounts = new List<UserAccount>();
                SaveAccounts();
            }
        }

        public static void SaveAccounts()
        {
            DataStorageUser.SaveUserAccounts(userAccounts, userAccountsFile);
        }
        internal static void SaveAccounts(string fileName)
        {
            DataStorageUser.SaveUserAccounts(userAccounts, fileName);
        }


        public static UserAccount GetUserAccount(SocketUser user, bool dontUse = true) ///// deleteeee // creates unwanted profiles
        {
            return GetOrCreateAccount(user.Id);
        }

        public static UserAccount GetOrCreateAccount(ulong id, bool dontUse = true) ///// deleteeee // creates unwanted profiles
        {
            var result = from a in userAccounts
                         where a.ID == id
                         select a;

            var account = result.FirstOrDefault();
            if (account == null) account = CreateUserAccount(id); 
            return account;
        }




        public static UserAccount GetOrCreateUserAccount(SocketUser user) 
        {
            var result = from a in userAccounts
                         where a.ID == user.Id
                         select a;

            var account = result.FirstOrDefault();
            if (account == null)
            {
                account = CreateUserAccount(user.Id);
            }            
            return account;
        }

        public static UserAccount GetUserAccount(SocketCommandContext forChannelAndUser, out bool accountExists, bool withNotificationIfAccountDoesNotExist = true)
        {
            return GetUserAccount(forChannelAndUser.User.Id, forChannelAndUser, out accountExists, withNotificationIfAccountDoesNotExist);

            /*var result = from a in userAccounts
                         where a.ID == forChannelAndUser.User.Id
                         select a;
            var userAccount = result.FirstOrDefault();

            if (userAccount == null)
            {
                accountExists = false;
                if (withNotificationIfAccountDoesNotExist == true) ProfilePrivacy.SendAccountFindingFailureNotification(forChannelAndUser);
            }
            else
            {
                accountExists = true;
            }

            return userAccount;*/
        }
        public static UserAccount GetUserAccount(ulong targetId)
        {
            var result = from a in userAccounts
                         where a.ID == targetId
                         select a;
            var userAccount = result.FirstOrDefault();
            return userAccount;
        }
        public static UserAccount GetUserAccount(ulong targetId, SocketCommandContext forChannel, out bool accountExists, bool withNotificationIfAccountDoesNotExist = true)
        {
            var result = from a in userAccounts
                         where a.ID == targetId
                         select a;
            var userAccount = result.FirstOrDefault();

            if (userAccount == null)
            {
                accountExists = false;
                if (withNotificationIfAccountDoesNotExist == true) ProfilePrivacy.SendAccountFindingFailureNotification(forChannel);
            }
            else
            {
                accountExists = true;
            }

            return userAccount;
        }

        

        private static UserAccount CreateUserAccount(ulong id)
        {
            var newAccount = new UserAccount()
            {
                Username = "",
                ID = id,
                DialogueProgress = 0,

                Language = "",
                AutoPrefix = false,
                    AutoPrefix_AddedString = null,
                    AutoPrefix_Notifications = true,
                    AutoPrefix_UnknownCommandsCounter = 0,
                PreferDM = false,
                
                CommandsUsed = 0,
                DateOfJoin = new System.DateTime(1, 1, 1),

                DateOfBirth = new System.DateTime(1, 1, 1),
               
                






                Restriction = 0,

                Points = 0,
                Currency = 500,
                Level = 0,
                XP = 0,
                TLastMessage = 61,
                TLastDaily = 0,
                NDailySeries = 0,
                NDailyPermanentSeries = 0,
                NDailyHighestSeries = 0,

                Sex = "",
                DoB = "",
                DoJ = "",
                PP = "https://cdn.discordapp.com/attachments/520251669615869954/537365739351310338/530239845625495553.png",

                Hex1 = 0,
                Hex2 = 191,
                Hex3 = 255,

                Alpha = 0,
                MembershipPluses = 0,
                TimeEvent = 0,

                // RTrash = 1

                CacheStatus = 1,
                TradingStatus = 0,
                NotificationStatus = 1,
                StoreCurrency = 0,
                StoreID = 0,
                RequestingPartnerID = 0,
                CacheRequestingPartnerID = 0,
                WantedPartnerID = 0,
                WantedObjectID = 0,
                OwnObjectID = 0,
                parts = new List<Part>(),
            };

            userAccounts.Add(newAccount);
            UserAccounts.SaveAccounts();
            return newAccount;
        }
    }
}
