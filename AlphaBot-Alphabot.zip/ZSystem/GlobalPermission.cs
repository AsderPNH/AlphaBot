﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Discord.WebSocket;

namespace AlphaBot.ZSystem
{
    class GlobalPermission
    {
        internal static bool HasGlobalPermission(SocketUser user)
        {
            return HasGlobalPermission(user.Id);
        }

        internal static bool HasGlobalPermission(ulong id)
        {
            string[] admins =  Config.bot.bot_Admins.Split('|');

            if (admins.Contains(id.ToString()) == true) return true;
            return false;
        }
    }
}
