﻿using System;
using System.Threading.Tasks;

using Discord.Commands;

using AlphaBot.Formatting;
using AlphaBot.DataManagement.ServerAccountsFolder;

using System.IO;
using AlphaBot.DataManagement.UserAccountsFolder;

namespace AlphaBot.ZSystem
{
    class Backup
    {
        internal static DateTime LastBackup { get; set; }
        internal static char LastBackupType { get; set; }

        internal static Task AutoBackup()
        {
            DateTime dateTimeNow = DateTime.Now;
            string timeNow = dateTimeNow.ToString("yyyyMMddHH"); // dateTime to formatted string 

            UserAccounts.SaveAccounts($"Resources/Backups/a{timeNow}userAccounts.json");
            ServerAccounts.SaveAccounts($"Resources/Backups/a{timeNow}serverAccounts.json");

            VirtualConsole.SendCasualLog($"autoBackup | {dateTimeNow}"); // Console alert            
            LastBackup = dateTimeNow; // updating the LastBackup var
            LastBackupType = 'a';
            return Task.CompletedTask;
        }

        public static Task ForcedBackup()
        {
            DateTime dateTimeNow = DateTime.Now;
            string timeNow = dateTimeNow.ToString("yyyyMMddHH"); // dateTime to formatted string 

            UserAccounts.SaveAccounts($"Resources/Backups/f{timeNow}userAccounts.json");
            ServerAccounts.SaveAccounts($"Resources/Backups/f{timeNow}serverAccounts.json");

            VirtualConsole.SendCasualLog($"forcedBackup | {dateTimeNow}"); // Console alert 
            LastBackup = dateTimeNow; // updating the LastBackup var
            LastBackupType = 'f';
            return Task.CompletedTask;
        }

        internal  static Task StartupBackup()
        {
            DateTime dateTimeNow = DateTime.Now;
            string timeNow = dateTimeNow.ToString("yyyyMMddHH"); // dateTime to formatted string 

            UserAccounts.SaveAccounts($"Resources/Backups/s{timeNow}userAccounts.json");
            ServerAccounts.SaveAccounts($"Resources/Backups/s{timeNow}serverAccounts.json");
            
            VirtualConsole.SendCasualLog($"startupBackup | {dateTimeNow}"); // Console alert
            LastBackup = dateTimeNow; // updating the LastBackup var
            LastBackupType = 's';
            return Task.CompletedTask;
        }

        internal static Task SetFilesStatus(bool status, SocketCommandContext context)
        {
            if (status == false) // make files unavailable
            {
                UserAccounts.SaveAccounts(); // save current data into recent file
                ServerAccounts.SaveAccounts();

                ForcedBackup(); // backing up the pre-FilesOffline-data

                DataStorageServer.ServerAccountFileAvailable = 0; // make files unavailable
                DataStorageUser.UserAccountFileAvailable = 0;
                LanguagePacks.LanguageFilesAvailable = false;
            }
            else // make files available
            {
                DataStorageServer.ServerAccountFileAvailable = 2; // thirdState = loading but no saving
                DataStorageUser.UserAccountFileAvailable = 2;

                UserAccounts.GetUserAccount(context.User); // loading the (new) data
                ServerAccounts.GetServerAccount(context.Guild);

                DataStorageServer.ServerAccountFileAvailable = 1; // make files available
                DataStorageUser.UserAccountFileAvailable = 1;
                LanguagePacks.LanguageFilesAvailable = true;
            }
            return Task.CompletedTask;
        }

        internal static Task GetFilesStatus(SocketCommandContext context)
        {
            context.Channel.SendMessageAsync($"{Utilities.GetAlert("EMOTE_abc")} | {LanguagePacks.LanguageFilesAvailable}" +
                $"\n{Utilities.GetAlert("EMOTE_server")} | {DataStorageServer.ServerAccountFileAvailable}" +
                $"\n{Utilities.GetAlert("EMOTE_userSilhouettes")} | {DataStorageUser.UserAccountFileAvailable}");
            return Task.CompletedTask;
        }

        internal static Task GetLastBackupInfo(SocketCommandContext context) // Last 
        {
            context.Channel.SendMessageAsync($"{Utilities.GetAlert("EMOTE_saveFile")}: " +
                $"({LastBackupType}){LastBackup}");
            return Task.CompletedTask;
        }

        internal static Task DeleteFiles(DateTime dateTime)
        {
            VirtualConsole.SendCasualLog($"startupBackup | {dateTime}"); // Console alert

            dateTime.AddMonths(-1); // subtracting month 
            UserAccounts.SaveAccounts($"Resources/Backups/MonthlyBackups/{dateTime.ToString("MM")}userAccounts.json"); // monthly backup with index of last month
            ServerAccounts.SaveAccounts($"Resources/Backups/MonthlyBackups/{dateTime.ToString("MM")}serverAccounts.json");
            
            dateTime.AddMonths(-1); // subtracting second month
            string[] files = Directory.GetFiles("Resources/Backups", $"*{dateTime.ToString("yyyyMM")}*"); // path + searchPatter (C...)
            int i = 0;
            foreach (string file in files) // for every backup, thats from penultimate month 
            {
                File.Delete(file); // deletes file
                i++; // count of deleted files
            }
            if (i > 0) VirtualConsole.SendCasualLog($"deletedBackups | Count: {i} | DatePattern: *{dateTime.ToString("yyyyMM")}*"); // Console alert
            
            return Task.CompletedTask;
        }
    }
}
