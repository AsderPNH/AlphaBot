﻿using System.Threading.Tasks;
using AlphaBot.ZSystem;
using Discord.WebSocket;

namespace AlphaBot
{
    class Global
    {        
        internal static DiscordSocketClient Client { get; set; }
        internal static ulong MessageIdToTrack { get; set; }
    }
}
