﻿using System;
using System.Linq;
using System.Threading.Tasks;

using Discord;
using Discord.WebSocket;


using AlphaBot.Modules.MiscSupply;
using AlphaBot.ZSystem;
using AlphaBot.DataManagement.ServerAccountsFolder;
using AlphaBot.DataManagement.UserAccountsFolder;

namespace AlphaBot
{
    class Program
    {
        DiscordSocketClient _client;
        CommandHandler _handler;
        internal static bool BotIsReady = false;

        static void Main(string[] args)
        => new Program().StartAsync().GetAwaiter().GetResult();

        public async Task StartAsync()
        {
            if (Config.bot.bot_token == "" || Config.bot.bot_token == null) return; // return if there is no token given

            _client = new DiscordSocketClient(new DiscordSocketConfig
            {
                LogLevel = LogSeverity.Debug,
                WebSocketProvider = Discord.Net.Providers.WS4Net.WS4NetProvider.Instance // provider to prevent ConnectionError
            });

            // events
            _client.Log += VirtualConsole.Log;             
            _client.Ready += DayCheck.StartTimer;
            _client.GuildAvailable += OnGuildAvailable;
            _client.ReactionAdded += OnReactionAdded;            
            _client.ReactionRemoved += OnReactionRemoved;

            // saving global client
            Global.Client = _client; 
            await _client.LoginAsync(TokenType.Bot, Config.bot.bot_token);
            await _client.StartAsync();

            // commandHandler
            _handler = new CommandHandler(); 
            await _handler.InitializeAsync(_client);

            // setting the availability vars
            DataStorageServer.ServerAccountFileAvailable = 1; 
            DataStorageUser.UserAccountFileAvailable = 1;
            Formatting.LanguagePacks.LanguageFilesAvailable = true;
            
            await Task.Delay(-1);            
        }
        
        

        internal static async Task OnBotIsReady()
        {
            await Backup.StartupBackup(); // startup-Backup of dynamic Files
            await Task.CompletedTask;
        }




        private async Task OnGuildAvailable(SocketGuild guild)
        {
            var serverAccount = ServerAccounts.GetOrCreateServerAccount(guild.Id);
            serverAccount.Servername = guild.Name;
            ServerAccounts.SaveAccounts();
        }

        private async Task OnReactionAdded(Cacheable<IUserMessage, ulong> cache, ISocketMessageChannel channel, SocketReaction reaction)
        {
            // Continue in Eingangshalle
            if (reaction.MessageId == 535238699324145685)
            {
                var user = (SocketGuildUser)reaction.User;
                var role = user.Roles.FirstOrDefault(x => x.Name.ToString() == "User"); // x Checkt nicht Rollen des Servers sondern des Users = nicht möglich
                await (user as IGuildUser).AddRoleAsync(role);

            }

            // Abstimmung
            if (reaction.MessageId == Global.MessageIdToTrack)
            {
                if (reaction.Emote.Name == "99")
                {
                    await channel.SendMessageAsync(reaction.User.Value.Username + " stimmt zu.");
                }
            }

            if (reaction.Channel.Id == 530118162658754560) // SettingsChannel
            {
                var account = UserAccounts.GetOrCreateAccount(reaction.UserId);
                if (reaction.MessageId == 530130022779060246) // TrashNachricht
                {
                    //account.RTrash = 1;
                }
            }
            UserAccounts.SaveAccounts();
        }

        private async Task OnReactionRemoved(Cacheable<IUserMessage, ulong> cache, ISocketMessageChannel channel, SocketReaction reaction)
        {
            if (reaction.Channel.Id == 530118162658754560) // SettingsChannel
            {
                //var account = UserAccounts.GetOrCreateAccount(reaction.UserId);
                if (reaction.MessageId == 99) // TrashNachricht
                {
                    //account.RTrash = 0;
                }
            }
            UserAccounts.SaveAccounts();
        }
    }
}
