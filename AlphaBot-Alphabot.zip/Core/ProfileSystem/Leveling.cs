﻿using System;
using AlphaBot.DataManagement.UserAccountsFolder;
using Discord.WebSocket;

namespace AlphaBot.Core.ProfileSystem
{
    internal static class Leveling
    {
        internal static async void UserSentMessage(SocketGuildUser user, SocketMessage message)
        {
            var account = UserAccounts.GetUserAccount(user);
            uint LevelFirst = account.Level;

            if (message.CreatedAt.Minute == account.TLastMessage
                || message.Content.Length < 2
                || message.Content.StartsWith(":") && message.Content.EndsWith(":"))
            {
                return;
            }

            Random r = new Random();
            int max = 6 + account.Points;
            if (max >= 11) max = 10;
            int min = 0 + account.Points;
            if (max >= 7) max = 6;
            int rInt = r.Next(min, max);            
            uint ruInt = Convert.ToUInt32(rInt);

            account.XP += ruInt;

            if (LevelFirst != account.Level)
            {
                if (account.Level < 10)
                {
                    account.Currency += 20;
                }
                else if (account.Level > 9 && account.Level < 25)
                {
                    account.Currency += 50;
                }
                else if (account.Level > 24 && account.Level < 40)
                {
                    account.Currency += 50;
                }
                else if (account.Level > 39 && account.Level < 50)
                {
                    account.Currency += 80;
                }
                else if (account.Level > 49 && account.Level < 101)
                {
                    account.Currency += 120;
                }
                await message.Channel.SendMessageAsync($":up: | **{user}**, Sie haben **Level {account.Level}** erreicht! :blue_heart:");
            }

            account.TLastMessage = Convert.ToByte(message.CreatedAt.Minute);
            UserAccounts.SaveAccounts();
        }

        internal static string LevelProcess(SocketUser user)
        {
            var account = UserAccounts.GetOrCreateAccount(user.Id);

            uint CurrentLevel = (uint)Math.Sqrt(account.XP / 50);
            uint NextLevel = CurrentLevel + 1;
            uint XPCurrentLevel = CurrentLevel * CurrentLevel * 50;
            uint XPNextLevel = NextLevel * NextLevel * 50;
            uint XPGap = XPNextLevel - XPCurrentLevel;
            uint XPOver = account.XP - XPCurrentLevel;
            uint XPStep = XPGap / 6;
            uint XPNeeded = XPGap - XPOver;
            string SProgress = "";

            if (XPOver >= 0 && XPOver <= XPStep * 1)
            {
                SProgress = "<:LevelFalse:538897224222900244><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244>";
            }
            else if (XPOver > XPStep * 1 && XPOver <= XPStep * 2)
            {
                SProgress = "<:LevelTrue:538896731660615681><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244>";
            }
            else if (XPOver > XPStep * 2 && XPOver <= XPStep * 3)
            {
                SProgress = "<:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244>";
            }
            else if (XPOver > XPStep * 3 && XPOver <= XPStep * 4)
            {
                SProgress = "<:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelFalse:538897224222900244><:LevelFalse:538897224222900244>";
            }
            else if (XPOver > XPStep * 4 && XPOver <= XPStep * 5)
            {
                SProgress = "<:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelFalse:538897224222900244>";
            }
            else if (XPOver > XPStep * 5 && XPOver <= XPStep * 6)
            {
                SProgress = "<:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelTrue:538896731660615681><:LevelTrue:538896731660615681>";
            }

            SProgress = XPOver + "XP " + SProgress + " " + XPGap + "XP\n"
                + "Lvl" + CurrentLevel + "  |  " + account.XP + "/" + XPNextLevel + "  |  Lvl" + NextLevel;
            return SProgress;
        }
    }
}
