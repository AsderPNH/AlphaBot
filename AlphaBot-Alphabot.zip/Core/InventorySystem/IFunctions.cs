﻿using System;
using System.Collections.Generic;
using AlphaBot.DataManagement.UserAccountsFolder;
using Discord.WebSocket;


namespace AlphaBot.Core.InventorySystem
{
    internal static class IFunctions
    {
        internal static int ItemGenFull(int WorthClothingWeaponFood, int Percent, int Kinds, int Multiplier, SocketUser User)
        {
            var account = UserAccounts.GetOrCreateAccount(User.Id);
            Random r = new Random();
            int rInt = r.Next(1, 100);
            if (rInt > Percent) return 0;
            int Right = 0;
            int Id = 0;
            while (Right != 1)
            {
                Id = GenerateItem(Kinds, Multiplier);
                if (WorthClothingWeaponFood == 1 && Id > 0 && Id < 201) Right = 1;
                else if (WorthClothingWeaponFood == 2 && Id > 200 && Id < 301) Right = 1;
                else if (WorthClothingWeaponFood == 3 && Id > 300 && Id < 501) Right = 1;
                else if (WorthClothingWeaponFood == 4 && Id > 500 && Id < 601) Right = 1;
            }
            return Id;

            // 1 - 200 = Wertgegenstände
            // 201 - 300 = Kleidung
            // 301 - 500 = Waffen
            // 501 - 600 = Essen
        }

        internal static int ItemGen(int Percent, int Kinds, int Multiplier, SocketUser User)
        {
            var account = UserAccounts.GetOrCreateAccount(User.Id);
            Random r = new Random();
            int rInt = r.Next(1, 100);
            if (rInt > Percent) return 0;
            int Id = GenerateItem(Kinds, Multiplier);
            return Id;
        }

        internal static void ClearInv(SocketUser User)
        {
            var account = UserAccounts.GetOrCreateAccount(User.Id);
            account.parts.Clear();
            UserAccounts.SaveAccounts();
        }

        internal static async void ShowInv(ISocketMessageChannel Channel, SocketUser User)
        {
            var account = UserAccounts.GetOrCreateAccount(User.Id);
            foreach (UserAccount.Part aPart in account.parts)
            {
                await Channel.SendMessageAsync(aPart.ToString());
            }
        }

        internal static void AddItem(int ItemId, int TimesItemPlus, SocketUser User)
        {
            List<UserAccount.Part> parts = new List<UserAccount.Part>();
            var account = UserAccounts.GetOrCreateAccount(User.Id);
            for (int i = 0; i < TimesItemPlus; i++)
            {
                account.parts.Add(new UserAccount.Part() { PartId = ItemId });
                Console.WriteLine("Added:" + ItemId);
            }
            UserAccounts.SaveAccounts();
            return;
        }

        internal static bool SubtractItem(int ItemId, int TimesItemMinus, SocketUser User)
        {
            var account = UserAccounts.GetOrCreateAccount(User.Id);
            if (account.parts.Exists(x => x.PartId == ItemId) != true)
            {
                return false;
            }
            int Index;
            int removed = 0;
            int Continue = 0;
            while (Continue < 1)
            {
                Index = account.parts.IndexOf(new UserAccount.Part() { PartId = ItemId });
                account.parts.RemoveAt(Index);
                removed++;
                if (account.parts.Exists(x => x.PartId == ItemId) != true)
                {
                    Continue = 1;
                }
            }
            int ItemRest = removed - TimesItemMinus;
            if (ItemRest > 0)
            {
                AddItem(ItemId, ItemRest, User);
                return true;
            }
            else if (ItemRest == 0)
            {
                return true;
            }
            else
            {
                AddItem(ItemId, removed, User);
                return false;
            }
        }

        internal static int GenerateItem(int Kinds, int Multiplier)
        {
            int ItemRarity = 5;
            int Id = 0;
            while (ItemRarity >= Kinds)
            {
                int ChanceEpic = 2;
                int ChanceRare = ChanceEpic * Multiplier;
                int ChanceUncommon = ChanceRare * Multiplier;
                int ChanceCommon = ChanceUncommon * Multiplier;
                int ChanceTotal = ChanceEpic + ChanceRare + ChanceUncommon + ChanceCommon;

                Random r = new Random();
                int rInt = r.Next(0, ChanceTotal);
                int Rarity = 0;
                if (rInt < ChanceEpic)
                {
                    Rarity = 4;
                }
                else
                {
                    if (rInt <= ChanceRare)
                    {
                        Rarity = 3;
                    }
                    else
                    {
                        if (rInt <= ChanceUncommon)
                        {
                            Rarity = 2;
                        }
                        else
                        {
                            if (rInt <= ChanceCommon)
                            {
                                Rarity = 1;
                            }
                        }
                    }
                }
                int Right = 0;
                while (Right != 1)
                {
                    Random r2 = new Random();
                    while (Right != 2)
                    {
                        rInt = r2.Next(1, 500);
                        if (Items.LookUpNameEmoteRarityWorthSpecial(rInt, 1) != "") Right = 2;
                    }
                    Id = rInt;
                    if (Rarity == 4) // Epic
                    {
                        if (Items.LookUpNameEmoteRarityWorthSpecial(rInt, 3) == "Epic") Right = 1;
                    }
                    else if (Rarity == 3) // Rare
                    {
                        if (Items.LookUpNameEmoteRarityWorthSpecial(rInt, 3) == "Rare") Right = 1;
                    }
                    else if (Rarity == 2) // Uncommon
                    {
                        if (Items.LookUpNameEmoteRarityWorthSpecial(rInt, 3) == "Uncommon") Right = 1;
                    }
                    else if (Rarity == 1) // Common
                    {
                        if (Items.LookUpNameEmoteRarityWorthSpecial(rInt, 3) == "Epic") Right = 1;
                    }
                }

                if (Items.LookUpNameEmoteRarityWorthSpecial(Id, 3) == "Epic")
                {
                    ItemRarity = 4;
                }
                else if (Items.LookUpNameEmoteRarityWorthSpecial(Id, 3) == "Rare")
                {
                    ItemRarity = 3;
                }
                else if (Items.LookUpNameEmoteRarityWorthSpecial(Id, 3) == "Uncommon")
                {
                    ItemRarity = 2;
                }
                else if (Items.LookUpNameEmoteRarityWorthSpecial(Id, 3) == "Common")
                {
                    ItemRarity = 1;
                }
            }
            return Id;
        }

        internal static int GenerateRandomItem(int AllWorthClothingWeaponFood, int Percent, int Kinds, int Multiplier)
        {
            Random r = new Random();
            int rInt = r.Next(1, 100);
            if (rInt > Percent) return 0;

            int ChanceEpic = 2;
            int ChanceRare = ChanceEpic * Multiplier; // 4
            int ChanceUncommon = ChanceRare * Multiplier; // 8
            int ChanceCommon = ChanceUncommon * Multiplier; // 16
            int ChanceTotal = ChanceEpic + ChanceRare + ChanceUncommon + ChanceCommon; // 30

            int ChanceLeast = 0;
            if (Kinds == 1) ChanceLeast = ChanceUncommon;
            else if (Kinds == 2) ChanceLeast = ChanceRare;
            else if (Kinds == 3) ChanceLeast = ChanceEpic;

            rInt = r.Next(ChanceLeast, ChanceTotal);
            string Rarity = "";
            if (rInt < ChanceEpic)
            {
                Rarity = "Epic";
            }
            else if (rInt <= ChanceRare)
            {
                Rarity = "Rare";
            }
            else if (rInt <= ChanceUncommon)
            {
                Rarity = "Uncommon";
            }
            else if (rInt <= ChanceCommon)
            {
                Rarity = "Common";
            }

            string ItemKind = "";
            if (AllWorthClothingWeaponFood == 2) ItemKind = "Valuable";
            else if (AllWorthClothingWeaponFood == 3) ItemKind = "Clothing";
            else if (AllWorthClothingWeaponFood == 4) ItemKind = "Weapon";
            else if (AllWorthClothingWeaponFood == 5) ItemKind = "Food";
            else
            {
                rInt = r.Next(0, 4);
                if (rInt == 0 || rInt == 1) ItemKind = "Valuable";
                else if (rInt == 2) ItemKind = "Clothing";
                else if (rInt == 3) ItemKind = "Weapon";
                else if (rInt == 4) ItemKind = "Food";
            }

            int Id = RandomItemGenList(Rarity, ItemKind);
            return Id;
        }

        internal static int RandomItemGenList(string Rarity, string ItemKind)
        {
            Random r = new Random();
            int ItemsHereTotal = 0;
            if (Rarity.Equals("Common") == true)
            {
                if (ItemKind.Equals("Valuable"))
                {
                    ItemsHereTotal = 1;
                    int rInt = r.Next(1, ItemsHereTotal);
                    if (rInt == 1) return 1;
                }
            }
            else if (Rarity.Equals("Uncommon") == true)
            {
                if (ItemKind.Equals("Valuable"))
                {
                    ItemsHereTotal = 1;
                    int rInt = r.Next(1, ItemsHereTotal);
                    if (rInt == 1) return 2;
                }
            }
            else if (Rarity.Equals("Rare") == true)
            {
                if (ItemKind.Equals("Valuable"))
                {
                    ItemsHereTotal = 1;
                    int rInt = r.Next(1, ItemsHereTotal);
                    if (rInt == 1) return 3;
                }
            }
            else if (Rarity.Equals("Epic") == true)
            {
                if (ItemKind.Equals("Valuable"))
                {
                    ItemsHereTotal = 1;
                    int rInt = r.Next(1, ItemsHereTotal);
                    if (rInt == 1) return 4;
                }
            }
            return 0;
        }

        /*internal static void AddItem(int ItemId, int TimesItemPlus, SocketUser User)
        {
            List<UserAccount.Part> parts = new List<UserAccount.Part>();
            var account = UserAccounts.UserAccounts.GetOrCreateAccount(User.Id);
            string ItemName = Items.LookUpNameEmoteRarityWorthSpecial(ItemId, 1);
            if (account.parts.Exists(x => x.PartId == ItemId) != true)
            {
                account.parts.Add(new UserAccount.Part() { PartTimesNumber = TimesItemPlus, PartId = ItemId, PartName = ItemName});
                Console.WriteLine("NotExistingList: TimesItemPlus: " + TimesItemPlus + " | ItemId: " + ItemId + " | ItemName: " + ItemName);
            }
            else
            {
                String Target = new UserAccount.Part() {PartId = ItemId}.ToString();
                String[] TargetParts = Target.Split(new Char[] { '|' });
                String TargetTimesNumber = TargetParts[0];                     
                int OldTimesNumber = Convert.ToInt32(TargetTimesNumber);
                int NewTimesNumber = OldTimesNumber + TimesItemPlus;
                Console.WriteLine("ExistingList: Target: (" + Target + ") | TargetTimesNumber: " + TargetTimesNumber + " | OldTimesNumber: " + OldTimesNumber + " | NewTimesNumber: " + NewTimesNumber); //
                int Index = account.parts.IndexOf(new UserAccount.Part() { PartId = ItemId });
                account.parts.RemoveAt(Index);

                account.parts.Add(new UserAccount.Part() { PartTimesNumber = NewTimesNumber,  PartId = ItemId, PartName = ItemName }); 
            }                       
            //CorrectInv(User);
            UserAccounts.UserAccounts.SaveAccounts();
            return;
        }

         internal static bool SubtractItem(int ItemId, int TimesItemMinus, SocketUser User)
         {
             var account = UserAccounts.UserAccounts.GetOrCreateAccount(User.Id);
             if (account.parts.Exists(x => x.PartId == ItemId) != true)
             {
                 return false;
             }
             string Target = new UserAccount.Part() { PartId = ItemId }.ToString();
             string ItemName = Items.LookUpNameEmoteRarityWorthSpecial(ItemId, 1);
             string[] TargetParts = Target.Split(new Char[] { '|' });
             string TargetTimesNumber = TargetParts[0];
             int OldTimesNumber = Convert.ToInt32(TargetTimesNumber);

             if (OldTimesNumber < TimesItemMinus)
             {
                 return false;
             }
             int Index = account.parts.IndexOf(new UserAccount.Part() { PartId = ItemId });
             account.parts.RemoveAt(Index);

             int NewTimesNumber = OldTimesNumber - TimesItemMinus;
             account.parts.Add(new UserAccount.Part() { PartTimesNumber = NewTimesNumber, PartId = ItemId }); 
             CorrectInv(User);
             UserAccounts.UserAccounts.SaveAccounts();
             return true;
         }

        internal static void CorrectInv(SocketUser User)
        {
            var account = UserAccounts.UserAccounts.GetOrCreateAccount(User.Id);
            account.parts.RemoveAll(x => x.PartTimesNumber == 0);
        }*/

    }
}
